/* global React, ReactDOM */
// =============================================================
// app.jsx — shell, nav, topbar, modal, theme
// =============================================================

const { useState, useEffect } = React;

const TABS = [
  { id: 'overview',     label: 'Overview',     icon: Icons.dashboard },
  { id: 'history',      label: 'History',      icon: Icons.history },
  { id: 'benchmark',    label: 'Benchmark',    icon: Icons.benchmark },
  { id: 'fundamentals', label: 'Fundamentals', icon: Icons.fundamentals },
  { id: 'dividends',    label: 'Dividends',    icon: Icons.sparkles },
  { id: 'risk',         label: 'Risk',         icon: Icons.risk },
  { id: 'hedging',      label: 'Hedging',      icon: Icons.risk },
  { id: 'stress',       label: 'Stress test',  icon: Icons.stress },
  { id: 'frontier',     label: 'Frontier',     icon: Icons.frontier },
  { id: 'markets',      label: 'Markets',      icon: Icons.benchmark },
  { id: 'cashflows',    label: 'Cashflows',    icon: Icons.download },
];

function Sidebar({ active, onNav }) {
  return (
    <aside className="side">
      <Wordmark />
      <nav className="nav">
        <div className="nav__label">Workspace</div>
        {TABS.map((t, i) => (
          <button key={t.id}
                  className={`nav__item ${active === t.id ? 'nav__item--active' : ''}`}
                  onClick={() => onNav(t.id)}>
            <span style={{ color: active === t.id ? 'var(--ink)' : 'var(--ink-3)', display: 'inline-flex' }}>{t.icon}</span>
            {t.label}
            <span className="kbd">{i + 1}</span>
          </button>
        ))}
      </nav>
      <div className="side__foot">
        <div className="user-card">
          <div className="user-card__avatar">DT</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="user-card__name">Dariush Tahajomi</div>
            <div className="user-card__plan">Pro · HSG '26</div>
          </div>
          {Icons.chevron}
        </div>
      </div>
    </aside>
  );
}

function Topbar({ activeTab, onAdd, theme, onTheme }) {
  const label = TABS.find(t => t.id === activeTab)?.label;
  return (
    <div className="topbar">
      <div className="crumbs">
        <span>My Portfolio</span>
        <span>/</span>
        <strong>{label}</strong>
      </div>
      <div className="topbar__tools">
        <MarketStatus />
        <div className="search">
          {Icons.search}
          <span>Search symbols, metrics…</span>
          <span className="kbd">⌘K</span>
        </div>
        <button className="icon-btn" title="Notifications">{Icons.bell}</button>
        <ThemeToggle theme={theme} onToggle={onTheme} />
        <button className="btn btn--ghost">{Icons.refresh}<span>Refresh</span></button>
        <button className="btn btn--primary" onClick={onAdd}>{Icons.plus}<span>Add position</span></button>
      </div>
    </div>
  );
}

function TabBar({ active, onChange }) {
  return (
    <div className="tabbar">
      {TABS.map(t => (
        <button key={t.id}
                className={`tabbar__btn ${active === t.id ? 'tabbar__btn--active' : ''}`}
                onClick={() => onChange(t.id)}>
          {t.label}
          {t.id === 'overview' && <span className="count">{POSITIONS.length}</span>}
        </button>
      ))}
    </div>
  );
}

function AddPositionModal({ open, onClose }) {
  const [ticker, setTicker] = useState('');
  const [shares, setShares] = useState('');
  const [price, setPrice]   = useState('');
  const [date, setDate]     = useState('2026-04-18');

  if (!open) return null;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal__head">
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 600, letterSpacing: '-0.01em' }}>Add position</div>
            <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginTop: 2 }}>Track a new holding in your portfolio</div>
          </div>
          <button className="icon-btn" onClick={onClose}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
          </button>
        </div>
        <div className="modal__body">
          <div className="field">
            <label className="field__label">Ticker symbol</label>
            <div className="input-combo">
              <div className="input-combo__prefix">{Icons.search}</div>
              <input value={ticker} onChange={e => setTicker(e.target.value.toUpperCase())} placeholder="AAPL, NVDA, MSFT…" />
            </div>
          </div>
          <div className="field__row">
            <div className="field">
              <label className="field__label">Shares</label>
              <input className="input" value={shares} onChange={e => setShares(e.target.value)} placeholder="100" />
            </div>
            <div className="field">
              <label className="field__label">Buy price</label>
              <div className="input-combo">
                <div className="input-combo__prefix">$</div>
                <input value={price} onChange={e => setPrice(e.target.value)} placeholder="0.00" />
              </div>
            </div>
          </div>
          <div className="field">
            <label className="field__label">Purchase date</label>
            <input className="input" type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div style={{ fontSize: 11.5, color: 'var(--ink-3)', padding: '8px 10px', borderLeft: '2px solid var(--pos)', background: 'var(--pos-soft)', borderRadius: 0, marginTop: 4 }}>
            Live price will be fetched from Alpha Vantage on save.
          </div>
        </div>
        <div className="modal__foot">
          <button className="btn btn--ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn--primary" onClick={onClose}>Add to portfolio</button>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [active, setActive] = useState(() => localStorage.getItem('pi_tab') || 'overview');
  const [theme, setTheme]   = useState(() => localStorage.getItem('pi_theme') || 'dark');
  const [modal, setModal]   = useState(false);

  useEffect(() => { localStorage.setItem('pi_tab', active); }, [active]);
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('pi_theme', theme);
  }, [theme]);

  // keyboard shortcuts for tab switching
  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= TABS.length) setActive(TABS[n - 1].id);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const handleDelete = () => { /* no-op in mock */ };

  return (
    <div className="app">
      <TickerTape />
      <Sidebar active={active} onNav={setActive} />
      <main className="main" data-screen-label={active}>
        <Topbar activeTab={active} onAdd={() => setModal(true)}
                theme={theme} onTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')} />
        <div className="page">
          <TabBar active={active} onChange={setActive} />
          {active === 'overview'     && <OverviewTab onAdd={() => setModal(true)} onDelete={handleDelete} />}
          {active === 'history'      && <HistoryTab />}
          {active === 'benchmark'    && <BenchmarkTab />}
          {active === 'fundamentals' && <FundamentalsTab />}
          {active === 'dividends'    && <DividendsTab />}
          {active === 'risk'         && <RiskTab />}
          {active === 'hedging'      && <HedgingTab />}
          {active === 'stress'       && <StressTestTab />}
          {active === 'frontier'     && <FrontierTab />}
          {active === 'markets'      && <MarketsTab />}
          {active === 'cashflows'    && <CashflowsTab />}
        </div>
      </main>
      <AddPositionModal open={modal} onClose={() => setModal(false)} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
