/* global React */
// =============================================================
// primitives.jsx — icons, wordmark, formatters, small UI atoms
// =============================================================

const { useState, useEffect, useRef, useMemo } = React;

// ---------- Formatters ----------
const fmt = {
  money: (n, d = 2) => n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }),
  moneyCompact: (n) => {
    const a = Math.abs(n);
    if (a >= 1e9) return (n / 1e9).toFixed(2) + 'B';
    if (a >= 1e6) return (n / 1e6).toFixed(2) + 'M';
    if (a >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return n.toFixed(2);
  },
  pct: (n, d = 2) => `${n >= 0 ? '+' : ''}${n.toFixed(d)}%`,
  signed: (n, d = 2) => `${n >= 0 ? '+' : '−'}${Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d })}`,
};

// ---------- Icons (stroke-based, 16px) ----------
const Icon = ({ d, size = 16, stroke = 1.6, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth={stroke}
       strokeLinecap="round" strokeLinejoin="round" style={style}>
    {d}
  </svg>
);
const Icons = {
  dashboard:   <Icon d={<><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></>} />,
  history:     <Icon d={<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/><path d="M3 12a9 9 0 0 1 9-9"/></>} />,
  benchmark:   <Icon d={<><path d="M3 17l6-6 4 4 8-8"/><path d="M14 7h7v7"/></>} />,
  fundamentals:<Icon d={<><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 9v12"/></>} />,
  risk:        <Icon d={<><path d="M12 3l9 16H3z"/><path d="M12 10v5"/><circle cx="12" cy="18" r="0.5" fill="currentColor" stroke="none"/></>} />,
  stress:      <Icon d={<><path d="M3 12h3l2-8 4 16 2-8h7"/></>} />,
  frontier:    <Icon d={<><path d="M3 20c4-12 10-14 18-14"/><circle cx="8" cy="16" r="1.5" fill="currentColor" stroke="none"/><circle cx="14" cy="10" r="1.5" fill="currentColor" stroke="none"/><circle cx="19" cy="7" r="1.5" fill="currentColor" stroke="none"/></>} />,
  search:      <Icon d={<><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></>} />,
  plus:        <Icon d={<><path d="M12 5v14M5 12h14"/></>} />,
  refresh:     <Icon d={<><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></>} />,
  download:    <Icon d={<><path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M5 21h14"/></>} />,
  trash:       <Icon d={<><path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M5 6l1 14a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2l1-14"/></>} />,
  sun:         <Icon d={<><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></>} />,
  moon:        <Icon d={<path d="M21 12.8A9 9 0 0 1 11.2 3a7 7 0 1 0 9.8 9.8z"/>} />,
  chevron:     <Icon d={<path d="M9 6l6 6-6 6"/>} />,
  settings:    <Icon d={<><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></>} />,
  bell:        <Icon d={<><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></>} />,
  arrowUp:     <Icon d={<><path d="M7 14l5-5 5 5"/></>} size={12} />,
  arrowDown:   <Icon d={<><path d="M7 10l5 5 5-5"/></>} size={12} />,
  sparkles:    <Icon d={<><path d="M12 3v5M12 16v5M3 12h5M16 12h5"/><path d="M5.6 5.6l3.5 3.5M14.9 14.9l3.5 3.5M5.6 18.4l3.5-3.5M14.9 9.1l3.5-3.5"/></>} />,
};

// ---------- Wordmark ----------
function Wordmark() {
  return (
    <div className="brand">
      <div className="brand__mark">P</div>
      <div>
        <div className="brand__name">Portfolio<br/>Intelligence</div>
        <div className="brand__tag">Pro · v4.2</div>
      </div>
    </div>
  );
}

// ---------- Sparkline ----------
function Sparkline({ data, width = 72, height = 24, stroke, fill, strokeWidth = 1.4 }) {
  const path = useMemo(() => {
    if (!data || data.length < 2) return { line: '', area: '' };
    const min = Math.min(...data), max = Math.max(...data);
    const range = max - min || 1;
    const w = width, h = height, pad = 1.5;
    const pts = data.map((v, i) => {
      const x = (i / (data.length - 1)) * (w - pad * 2) + pad;
      const y = h - pad - ((v - min) / range) * (h - pad * 2);
      return [x, y];
    });
    const line = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0].toFixed(2) + ',' + p[1].toFixed(2)).join(' ');
    const area = line + ` L ${pts[pts.length - 1][0]},${h} L ${pts[0][0]},${h} Z`;
    return { line, area };
  }, [data, width, height]);

  const dir = data[data.length - 1] >= data[0] ? 'pos' : 'neg';
  const color = stroke || (dir === 'pos' ? 'var(--pos)' : 'var(--neg)');
  const fillC = fill  || (dir === 'pos' ? 'var(--pos-soft)' : 'var(--neg-soft)');

  return (
    <svg width={width} height={height} style={{ display: 'block', overflow: 'visible' }}>
      <path d={path.area} fill={fillC} />
      <path d={path.line} fill="none" stroke={color} strokeWidth={strokeWidth}
            strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ---------- Ticker tape ----------
function TickerTape() {
  const items = [...TAPE, ...TAPE]; // duplicate for seamless loop
  return (
    <div className="ticker-tape">
      <div className="ticker-tape__label">
        <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: 'var(--pos)', boxShadow: '0 0 8px var(--pos)' }} />
        Live
      </div>
      <div className="ticker-tape__track">
        {items.map((t, i) => (
          <div key={i} className="ticker-tape__item">
            <span className="ticker-tape__sym">{t.sym}</span>
            <span className="ticker-tape__px">{t.px}</span>
            <span className={`ticker-tape__chg ${t.dir}`}>{t.chg}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- Market status ----------
function MarketStatus() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // NYSE 9:30–16:00 ET, Mon–Fri. We'll simulate by using hours UTC-ish
  const hours = now.getUTCHours();
  const day = now.getUTCDay();
  const open = day >= 1 && day <= 5 && hours >= 13 && hours < 20; // 13–20 UTC ≈ NYSE

  return (
    <div className={`pill ${open ? 'pill--open' : 'pill--closed'}`}>
      <span className="pill__dot" />
      {open ? 'Market open' : 'After hours'}
      <span style={{ color: 'var(--ink-4)', marginLeft: 4 }}>
        {now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })} ET
      </span>
    </div>
  );
}

// ---------- Theme toggle ----------
function ThemeToggle({ theme, onToggle }) {
  return (
    <button className="icon-btn" onClick={onToggle} title="Toggle theme">
      {theme === 'dark' ? Icons.sun : Icons.moon}
    </button>
  );
}

// ---------- Empty sector logos: 2-letter mark ----------
function TickerMark({ p }) {
  return (
    <div className="sym__logo" style={{ background: p.color + '22', color: p.color, borderColor: p.color + '40' }}>
      {p.ticker.slice(0, 2)}
    </div>
  );
}

// ---------- Arrow chip ----------
function Delta({ value, suffix = '%', positiveIsGood = true, size = 'md' }) {
  if (value == null) return <span className="muted">—</span>;
  const good = positiveIsGood ? value >= 0 : value < 0;
  const cls = good ? 'pos' : 'neg';
  const arrow = value >= 0 ? Icons.arrowUp : Icons.arrowDown;
  return (
    <span className={`delta-chip ${cls}`} style={size === 'sm' ? { fontSize: 11, padding: '2px 8px' } : {}}>
      {arrow}
      {Math.abs(value).toFixed(2)}{suffix}
    </span>
  );
}

Object.assign(window, {
  fmt, Icons, Wordmark, Sparkline, TickerTape, MarketStatus, ThemeToggle, TickerMark, Delta,
});
