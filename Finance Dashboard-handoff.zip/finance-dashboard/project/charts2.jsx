/* global React */
// charts2.jsx — Treemap, HBar, StackedBar, Waffle, Calendar

const { useState: u2s, useMemo: u2m, useRef: u2r, useEffect: u2e } = React;

// ---------- Treemap (simple squarified, horizontal slice) ----------
function TreemapChart({ data, width = 600, height = 320 }) {
  // sort desc
  const items = u2m(() => [...data].sort((a, b) => b.value - a.value), [data]);
  const total = items.reduce((s, d) => s + d.value, 0);

  // slice & dice: alternate direction each row; pack rows by aspect ratio heuristic
  const rects = u2m(() => {
    const out = [];
    let remaining = items.slice();
    let x = 0, y = 0, w = width, h = height;

    // Squarified: group a "row" greedily while aspect improves
    const worst = (row, length) => {
      const sum = row.reduce((s, r) => s + r.value, 0);
      const maxv = Math.max(...row.map(r => r.value));
      const minv = Math.min(...row.map(r => r.value));
      const s2 = sum * sum;
      return Math.max((length * length * maxv) / s2, s2 / (length * length * minv));
    };

    while (remaining.length) {
      const shortSide = Math.min(w, h);
      let row = [];
      while (remaining.length) {
        const test = [...row, remaining[0]];
        if (row.length === 0 || worst(test, shortSide) <= worst(row, shortSide)) {
          row.push(remaining.shift());
        } else break;
      }
      // layout row along long side
      const sum = row.reduce((s, r) => s + r.value, 0);
      const area = sum / remaining.concat(row).reduce((s, r) => s + r.value, 0) * (w * h);
      const rowThickness = area / shortSide;
      let cursor = 0;
      row.forEach(r => {
        const ratio = r.value / sum;
        const cellLong = ratio * shortSide;
        if (w >= h) {
          out.push({ ...r, x, y: y + cursor, w: rowThickness, h: cellLong });
        } else {
          out.push({ ...r, x: x + cursor, y, w: cellLong, h: rowThickness });
        }
        cursor += cellLong;
      });
      if (w >= h) { x += rowThickness; w -= rowThickness; }
      else        { y += rowThickness; h -= rowThickness; }
    }
    return out;
  }, [items, width, height]);

  return (
    <svg width="100%" viewBox={`0 0 ${width} ${height}`} style={{ display: 'block', borderRadius: 10 }}>
      {rects.map((r, i) => {
        const pct = (r.value / total) * 100;
        const bigEnough = r.w > 44 && r.h > 28;
        const biggest = r.w > 90 && r.h > 60;
        return (
          <g key={i}>
            <rect x={r.x + 2} y={r.y + 2} width={Math.max(0, r.w - 4)} height={Math.max(0, r.h - 4)}
                  fill={r.color} opacity={0.88}
                  rx={6} stroke="var(--bg)" strokeWidth="1" />
            {bigEnough && (
              <>
                <text x={r.x + 10} y={r.y + 18} fill="var(--bg)" fontFamily="var(--font-mono)"
                      fontWeight="700" fontSize={biggest ? 14 : 11}
                      style={{ mixBlendMode: 'normal' }}>
                  {r.name}
                </text>
                <text x={r.x + 10} y={r.y + (biggest ? 36 : 30)} fill="var(--bg)" opacity={0.75}
                      fontFamily="var(--font-mono)" fontSize={biggest ? 11 : 10}>
                  {pct.toFixed(1)}%
                </text>
              </>
            )}
          </g>
        );
      })}
    </svg>
  );
}

// ---------- Horizontal bar chart ----------
function HBarChart({ data, valueSuffix = '%', height = 340 }) {
  const total = data.reduce((s, d) => s + d.value, 0);
  const max = Math.max(...data.map(d => d.value));
  return (
    <div style={{ padding: '12px 4px', display: 'flex', flexDirection: 'column', gap: 10 }}>
      {data.map((d, i) => {
        const pct = (d.value / total) * 100;
        const barPct = (d.value / max) * 100;
        return (
          <div key={d.name} style={{ display: 'grid', gridTemplateColumns: '130px 1fr 80px', alignItems: 'center', gap: 12, fontSize: 12.5 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--ink)' }}>
              <span style={{ width: 10, height: 10, borderRadius: 3, background: d.color, flexShrink: 0 }} />
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.name}</span>
            </div>
            <div style={{ position: 'relative', height: 18, background: 'var(--bg-3)', borderRadius: 4, overflow: 'hidden' }}>
              <div style={{
                position: 'absolute', top: 0, bottom: 0, left: 0,
                width: `${barPct}%`, background: d.color, opacity: 0.9,
                transition: 'width 0.5s ease',
              }} />
              <div style={{
                position: 'absolute', inset: 0, display: 'flex', alignItems: 'center',
                paddingLeft: 8, fontFamily: 'var(--font-mono)', fontSize: 10.5,
                color: 'var(--bg)', fontWeight: 600,
              }}>
                ${fmt.moneyCompact(d.value)}
              </div>
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', textAlign: 'right', color: 'var(--ink)', fontWeight: 500 }}>
              {pct.toFixed(1)}{valueSuffix}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ---------- Stacked bar (single row, full-width) ----------
function StackedBar({ data, height = 36 }) {
  const total = data.reduce((s, d) => s + d.value, 0);
  let acc = 0;
  return (
    <div style={{ display: 'flex', width: '100%', height, borderRadius: 8, overflow: 'hidden', background: 'var(--bg-3)' }}>
      {data.map((d, i) => {
        const w = (d.value / total) * 100;
        acc += w;
        return (
          <div key={i} title={`${d.name}: ${w.toFixed(1)}%`}
               style={{
                 width: `${w}%`,
                 background: d.color,
                 borderRight: i < data.length - 1 ? '1px solid var(--bg)' : 'none',
                 display: 'flex', alignItems: 'center', justifyContent: 'center',
                 fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--bg)', fontWeight: 600,
                 overflow: 'hidden',
               }}>
            {w > 6 ? `${w.toFixed(0)}%` : ''}
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, { TreemapChart, HBarChart, StackedBar });
