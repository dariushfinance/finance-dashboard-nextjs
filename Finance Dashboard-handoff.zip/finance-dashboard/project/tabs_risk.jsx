/* global React */
// =============================================================
// tabs_risk.jsx — Risk, Stress Test, Frontier tabs
// =============================================================

function RiskTab() {
  const { sharpe, sortino, volatility, max_drawdown, var95, cvar95 } = TOTALS;

  const risks = [
    { label: 'Sharpe ratio',   val: sharpe.toFixed(2),  pct: Math.min(100, sharpe / 3 * 100),   color: 'var(--pos)', desc: 'Risk-adjusted return · higher is better' },
    { label: 'Sortino ratio',  val: sortino.toFixed(2), pct: Math.min(100, sortino / 3 * 100),  color: 'var(--pos)', desc: 'Downside risk-adjusted return' },
    { label: 'Volatility',     val: volatility.toFixed(1) + '%', pct: volatility / 30 * 100,    color: 'var(--warn)', desc: 'Annualized std. deviation' },
    { label: 'Max drawdown',   val: max_drawdown.toFixed(1) + '%', pct: Math.abs(max_drawdown) / 40 * 100, color: 'var(--neg)', desc: 'Peak-to-trough loss' },
    { label: 'VaR 95%',        val: var95.toFixed(2) + '%', pct: Math.abs(var95) / 10 * 100,    color: 'var(--neg)', desc: '1-day loss at 95% confidence' },
    { label: 'CVaR 95%',       val: cvar95.toFixed(2) + '%', pct: Math.abs(cvar95) / 10 * 100,  color: 'var(--neg)', desc: 'Expected shortfall in tail events' },
  ];

  return (
    <>
      <div className="three-col">
        {risks.slice(0, 3).map(r => (
          <div key={r.label} className="card risk-big">
            <div>
              <div className="eyebrow">{r.label}</div>
              <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 4 }}>{r.desc}</div>
            </div>
            <div className="risk-val-row">
              <div className="risk-val">{r.val}</div>
              <div className="risk-delta">
                {r.label === 'Sharpe ratio' && 'vs 0.5 benchmark'}
                {r.label === 'Sortino ratio' && 'vs 1.0 benchmark'}
                {r.label === 'Volatility' && '30-day rolling'}
              </div>
            </div>
            <div className="risk-gauge">
              <div className="risk-gauge__fill" style={{ width: `${Math.min(100, r.pct)}%`, background: r.color }} />
            </div>
          </div>
        ))}
      </div>
      <div className="three-col" style={{ marginTop: 14 }}>
        {risks.slice(3).map(r => (
          <div key={r.label} className="card risk-big">
            <div>
              <div className="eyebrow">{r.label}</div>
              <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 4 }}>{r.desc}</div>
            </div>
            <div className="risk-val-row">
              <div className="risk-val neg">{r.val}</div>
              <div className="risk-delta">historical, 1Y</div>
            </div>
            <div className="risk-gauge">
              <div className="risk-gauge__fill" style={{ width: `${Math.min(100, r.pct)}%`, background: r.color }} />
            </div>
          </div>
        ))}
      </div>

      <div className="spacer-20" />

      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Correlation matrix</div>
            <div className="card__sub">Pairwise daily return correlation · last 180 days</div>
          </div>
          <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--ink-3)' }}>
            Avg off-diagonal: <strong style={{ color: 'var(--ink)' }}>0.42</strong>
          </div>
        </div>
        <CorrelationGrid />
      </div>
    </>
  );
}

function CorrelationGrid() {
  const { tickers, matrix } = CORRELATION;
  const n = tickers.length;
  const gridCols = `80px repeat(${n}, 1fr)`;

  const cellColor = (v) => {
    if (v == null) return 'transparent';
    if (v >= 0) {
      // green scale
      return `oklch(0.80 ${0.04 + v * 0.14} 160 / ${0.12 + v * 0.7})`;
    }
    return `oklch(0.70 ${0.04 + Math.abs(v) * 0.14} 25 / ${0.12 + Math.abs(v) * 0.7})`;
  };

  return (
    <div className="heatmap">
      <div className="heatmap__row" style={{ gridTemplateColumns: gridCols }}>
        <div />
        {tickers.map(t => <div key={t} className="heatmap__hdr">{t}</div>)}
      </div>
      {matrix.map((row, i) => (
        <div key={i} className="heatmap__row" style={{ gridTemplateColumns: gridCols }}>
          <div className="heatmap__hdr" style={{ justifyContent: 'flex-end', paddingRight: 10 }}>{tickers[i]}</div>
          {row.map((v, j) => (
            <div key={j} className="heatmap__cell"
                 style={{ background: cellColor(v), color: Math.abs(v) > 0.6 ? 'var(--ink)' : 'var(--ink-2)' }}
                 title={`${tickers[i]} × ${tickers[j]}: ${v.toFixed(2)}`}>
              {v.toFixed(2)}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function StressTestTab() {
  const [selected, setSelected] = React.useState('covid');
  const sc = SCENARIOS.find(s => s.id === selected);
  const dollarImpact = TOTALS.total_value * (sc.impact_pct / 100);
  const maxAbs = Math.max(...SCENARIOS.map(s => Math.abs(s.impact_pct)));

  return (
    <>
      <div className="card" style={{ padding: 22 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 22, alignItems: 'stretch' }}>
          <div>
            <div className="eyebrow">Scenario outcome</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, marginTop: 8, color: 'var(--ink)' }}>
              {sc.name}
            </div>
            <div style={{ color: 'var(--ink-3)', fontSize: 12.5, marginTop: 4 }}>{sc.desc}</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginTop: 24 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 52, fontWeight: 600, letterSpacing: '-0.03em', color: sc.impact_pct >= 0 ? 'var(--pos)' : 'var(--neg)' }}>
                {fmt.pct(sc.impact_pct, 1)}
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 15, color: sc.impact_pct >= 0 ? 'var(--pos)' : 'var(--neg)' }}>
                {dollarImpact >= 0 ? '+' : '−'}${fmt.money(Math.abs(dollarImpact), 0)}
              </div>
            </div>
            <div style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div>
                <div className="eyebrow">Portfolio after</div>
                <div className="mono" style={{ fontSize: 16, marginTop: 3, color: 'var(--ink)' }}>
                  ${fmt.money(TOTALS.total_value + dollarImpact, 0)}
                </div>
              </div>
              <div>
                <div className="eyebrow">Recovery est.</div>
                <div className="mono" style={{ fontSize: 16, marginTop: 3, color: 'var(--ink)' }}>
                  {Math.max(1, Math.round(Math.abs(sc.impact_pct) / 1.2))} mo
                </div>
              </div>
            </div>
          </div>

          <div style={{ background: 'var(--bg)', borderRadius: 12, border: '1px solid var(--line-soft)', padding: 18 }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}>Position-level impact</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {POSITIONS.slice(0, 6).map(p => {
                // simulate beta-weighted impact
                const b = 0.8 + (p.seed % 7) / 10;
                const impact = p.current_value * sc.impact_pct / 100 * b;
                return (
                  <div key={p.id} style={{ display: 'grid', gridTemplateColumns: '60px 1fr 80px', alignItems: 'center', gap: 10, fontSize: 12 }}>
                    <div className="mono" style={{ fontWeight: 600 }}>{p.ticker}</div>
                    <div style={{ position: 'relative', height: 6, background: 'var(--bg-3)', borderRadius: 3 }}>
                      <div style={{
                        position: 'absolute', top: 0, bottom: 0,
                        width: `${Math.abs(impact) / (TOTALS.total_value * 0.1) * 100}%`,
                        background: sc.impact_pct >= 0 ? 'var(--pos)' : 'var(--neg)',
                        borderRadius: 3, maxWidth: '100%',
                      }} />
                    </div>
                    <div className={`mono ${impact >= 0 ? 'pos' : 'neg'}`} style={{ textAlign: 'right' }}>
                      {impact >= 0 ? '+' : '−'}${fmt.moneyCompact(Math.abs(impact))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="spacer-20" />

      <div className="card" style={{ padding: 22 }}>
        <div style={{ marginBottom: 14 }}>
          <div className="card__title">Historical scenarios</div>
          <div className="card__sub">Click to simulate impact on your portfolio</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {SCENARIOS.map(s => {
            const isSel = s.id === selected;
            return (
              <div key={s.id}
                   className={`scenario ${isSel ? 'scenario--selected' : ''}`}
                   onClick={() => setSelected(s.id)}>
                <div>
                  <div className="scenario__name">{s.name}</div>
                  <div className="scenario__desc">{s.desc}</div>
                </div>
                <div className="scenario__impact" style={{ color: s.impact_pct >= 0 ? 'var(--pos)' : 'var(--neg)' }}>
                  {fmt.pct(s.impact_pct, 1)}
                  <div className="bar">
                    <div className="bar__fill" style={{
                      width: `${Math.abs(s.impact_pct) / maxAbs * 100}%`,
                      background: s.impact_pct >= 0 ? 'var(--pos)' : 'var(--neg)',
                      right: s.impact_pct >= 0 ? 'auto' : 0,
                      left: s.impact_pct >= 0 ? 0 : 'auto',
                    }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

function FrontierTab() {
  const [constraint, setConstraint] = React.useState('unconstrained');

  // current & optimal vary with constraint
  const profiles = {
    unconstrained: { current: { vol: TOTALS.volatility, ret: TOTALS.total_return / 2 }, optimal: { vol: 11.2, ret: 18.4 }, lift: 0.42 },
    'max-20':      { current: { vol: TOTALS.volatility, ret: TOTALS.total_return / 2 }, optimal: { vol: 12.6, ret: 16.8 }, lift: 0.31 },
    'no-shorts':   { current: { vol: TOTALS.volatility, ret: TOTALS.total_return / 2 }, optimal: { vol: 13.4, ret: 15.9 }, lift: 0.24 },
  };
  const { current, optimal, lift } = profiles[constraint];

  return (
    <>
      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Efficient frontier</div>
            <div className="card__sub">Expected return vs. volatility across rebalanced allocations</div>
          </div>
          <div className="chip-group">
            <button className={constraint === 'unconstrained' ? 'active' : ''} onClick={() => setConstraint('unconstrained')}>Unconstrained</button>
            <button className={constraint === 'max-20' ? 'active' : ''} onClick={() => setConstraint('max-20')}>Max 20% / position</button>
            <button className={constraint === 'no-shorts' ? 'active' : ''} onClick={() => setConstraint('no-shorts')}>No shorts</button>
          </div>
        </div>
        <div className="frontier-legend">
          <span className="legend-marker">
            <span className="legend-marker__mark" style={{ background: 'var(--neg)' }} />
            Your portfolio · <strong className="mono" style={{ color: 'var(--ink)' }}>{current.vol.toFixed(1)}% vol / {current.ret.toFixed(1)}% ret</strong>
          </span>
          <span className="legend-marker">
            <span className="legend-marker__mark" style={{ background: 'var(--pos)' }} />
            Optimal (max Sharpe) · <strong className="mono" style={{ color: 'var(--ink)' }}>{optimal.vol.toFixed(1)}% vol / {optimal.ret.toFixed(1)}% ret</strong>
          </span>
          <span className="legend-marker" style={{ marginLeft: 'auto' }}>
            <span style={{ color: 'var(--ink-4)', fontSize: 11 }}>Sharpe lift</span>
            <strong className="mono pos">+{lift.toFixed(2)}</strong>
          </span>
        </div>
        <div className="chart-wrap" style={{ paddingTop: 0 }}>
          <ScatterChart points={FRONTIER} height={360} currentPortfolio={current} optimal={optimal} />
        </div>
      </div>

      <div className="spacer-20" />

      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Rebalance suggestion</div>
            <div className="card__sub">Weights to move from <em>Your portfolio</em> → <em>Optimal</em></div>
          </div>
          <button className="btn btn--primary">Apply rebalance →</button>
        </div>
        <div style={{ padding: 20 }}>
          {POSITIONS.map(p => {
            const cur = p.current_value / TOTALS.total_value * 100;
            const tgt = cur + (mulberry32(p.seed * 3)() - 0.5) * 10;
            const diff = tgt - cur;
            return (
              <div key={p.id} style={{ display: 'grid', gridTemplateColumns: '100px 1fr 100px 60px', alignItems: 'center', gap: 14, padding: '10px 4px', borderBottom: '1px solid var(--line-soft)' }}>
                <div className="sym">
                  <div className="sym__ticker">{p.ticker}</div>
                </div>
                <div style={{ position: 'relative', height: 22, background: 'var(--bg-3)', borderRadius: 4 }}>
                  <div style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: `${cur}%`, background: 'var(--ink-4)', opacity: 0.5, borderRadius: 4 }} />
                  <div style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: `${tgt}%`, background: p.color, opacity: 0.85, borderRadius: 4, transition: 'width 0.5s ease' }} />
                  <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', paddingLeft: 8, fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--ink)' }}>
                    {cur.toFixed(1)}% → {tgt.toFixed(1)}%
                  </div>
                </div>
                <div className={`mono ${diff >= 0 ? 'pos' : 'neg'}`} style={{ textAlign: 'right', fontSize: 12 }}>
                  {diff >= 0 ? '+' : '−'}{Math.abs(diff).toFixed(1)}pp
                </div>
                <div className="mono" style={{ textAlign: 'right', fontSize: 11, color: 'var(--ink-4)' }}>
                  {diff >= 0 ? 'BUY' : 'SELL'}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

Object.assign(window, { RiskTab, StressTestTab, FrontierTab });
