/* global React */
// =============================================================
// data.jsx — realistic portfolio data + mock series generators
// =============================================================

// Deterministic PRNG so sparklines are stable across renders
function mulberry32(seed) {
  return function () {
    let t = (seed += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function genWalk(n, start, vol, drift, seed) {
  const rand = mulberry32(seed);
  const out = [];
  let v = start;
  for (let i = 0; i < n; i++) {
    const shock = (rand() - 0.5) * vol;
    v = v * (1 + drift + shock);
    out.push(v);
  }
  return out;
}

const POSITIONS = [
  { id: 1, ticker: 'NVDA', name: 'NVIDIA Corp',        shares: 42,  buy_price: 412.30, current_price: 942.18, sector: 'Technology',         industry: 'Semiconductors',      region: 'North America', country: 'USA',         type: 'Stock', currency: 'USD', dividend_yield: 0.03, seed: 11, color: 'oklch(0.80 0.14 160)' },
  { id: 2, ticker: 'AAPL', name: 'Apple Inc.',          shares: 120, buy_price: 168.45, current_price: 224.31, sector: 'Technology',         industry: 'Consumer Electronics',region: 'North America', country: 'USA',         type: 'Stock', currency: 'USD', dividend_yield: 0.48, seed: 22, color: 'oklch(0.72 0.12 240)' },
  { id: 3, ticker: 'MSFT', name: 'Microsoft Corp',      shares: 68,  buy_price: 338.22, current_price: 438.90, sector: 'Technology',         industry: 'Software',            region: 'North America', country: 'USA',         type: 'Stock', currency: 'USD', dividend_yield: 0.73, seed: 33, color: 'oklch(0.70 0.14 200)' },
  { id: 4, ticker: 'ASML', name: 'ASML Holding',        shares: 14,  buy_price: 742.00, current_price: 918.52, sector: 'Technology',         industry: 'Semiconductors',      region: 'Europe',        country: 'Netherlands', type: 'Stock', currency: 'EUR', dividend_yield: 0.94, seed: 44, color: 'oklch(0.75 0.13 140)' },
  { id: 5, ticker: 'V',    name: 'Visa Inc.',           shares: 55,  buy_price: 238.10, current_price: 286.04, sector: 'Financials',         industry: 'Payments',            region: 'North America', country: 'USA',         type: 'Stock', currency: 'USD', dividend_yield: 0.74, seed: 55, color: 'oklch(0.78 0.12 80)'  },
  { id: 6, ticker: 'COST', name: 'Costco Wholesale',    shares: 18,  buy_price: 542.00, current_price: 892.17, sector: 'Consumer Discretionary', industry: 'Retail',          region: 'North America', country: 'USA',         type: 'Stock', currency: 'USD', dividend_yield: 0.52, seed: 66, color: 'oklch(0.70 0.14 30)'  },
  { id: 7, ticker: 'LVMH', name: 'LVMH Moët Hennessy',  shares: 9,   buy_price: 812.40, current_price: 725.80, sector: 'Consumer Discretionary', industry: 'Luxury Goods',    region: 'Europe',        country: 'France',      type: 'Stock', currency: 'EUR', dividend_yield: 1.84, seed: 77, color: 'oklch(0.65 0.14 340)' },
  { id: 8, ticker: 'NESN', name: 'Nestlé SA',           shares: 86,  buy_price:  98.20, current_price:  87.54, sector: 'Consumer Staples',   industry: 'Packaged Foods',      region: 'Europe',        country: 'Switzerland', type: 'Stock', currency: 'CHF', dividend_yield: 3.28, seed: 88, color: 'oklch(0.72 0.11 110)' },
  { id: 9, ticker: 'SHOP', name: 'Shopify Inc.',        shares: 45,  buy_price:  54.20, current_price:  78.11, sector: 'Technology',         industry: 'E-commerce',          region: 'North America', country: 'Canada',      type: 'Stock', currency: 'CAD', dividend_yield: 0.00, seed: 99, color: 'oklch(0.78 0.12 280)' },
  { id: 10,ticker: 'VWCE', name: 'Vanguard FTSE All-World', shares: 28, buy_price: 108.50, current_price: 128.40, sector: 'Diversified',       industry: 'World ETF',           region: 'Global',        country: 'Ireland',     type: 'ETF',   currency: 'EUR', dividend_yield: 1.82, seed: 110, color: 'oklch(0.72 0.12 50)' },
  { id: 11,ticker: 'IEF',  name: 'iShares 7-10Y Treasury', shares: 60, buy_price: 92.80,  current_price: 95.12,  sector: 'Fixed Income',      industry: 'Gov Bonds',           region: 'North America', country: 'USA',         type: 'Bond',  currency: 'USD', dividend_yield: 3.42, seed: 120, color: 'oklch(0.72 0.10 70)' },
  { id: 12,ticker: 'BTC',  name: 'Bitcoin',             shares: 0.28, buy_price: 48200,  current_price: 84112,   sector: 'Digital Assets',    industry: 'Cryptocurrency',      region: 'Global',        country: '—',           type: 'Crypto',currency: 'USD', dividend_yield: 0.00, seed: 130, color: 'oklch(0.74 0.14 60)' },
];

// Enrich
POSITIONS.forEach(p => {
  p.invested       = p.shares * p.buy_price;
  p.current_value  = p.shares * p.current_price;
  p.pnl            = p.current_value - p.invested;
  p.return_pct     = (p.current_price / p.buy_price - 1) * 100;
  p.day_change_pct = (mulberry32(p.seed * 7)() - 0.42) * 4;   // -1.7 .. +2.3
  p.day_change     = p.current_value * p.day_change_pct / 100;
  // 30-day sparkline price walk, ending at current_price
  const walk = genWalk(30, p.current_price * 0.90, 0.06, 0.004, p.seed);
  const last = walk[walk.length - 1];
  const scale = p.current_price / last;
  p.spark = walk.map(v => v * scale);
});

const TOTALS = (() => {
  const tv = POSITIONS.reduce((s, p) => s + p.current_value, 0);
  const ti = POSITIONS.reduce((s, p) => s + p.invested, 0);
  const dc = POSITIONS.reduce((s, p) => s + p.day_change, 0);
  return {
    total_value: tv,
    total_invested: ti,
    total_pnl: tv - ti,
    total_return: (tv / ti - 1) * 100,
    day_change: dc,
    day_change_pct: (dc / (tv - dc)) * 100,
    sharpe: 1.82,
    volatility: 14.6,
    sortino: 2.41,
    max_drawdown: -12.8,
    var95: -3.42,
    cvar95: -4.91,
    beta: 1.08,
    alpha: 4.2,
    information_ratio: 0.74,
    cash: 4820.55,
    positions_count: POSITIONS.length,
  };
})();

// 180-day portfolio history, normalized so last point = total_value
const HISTORY = (() => {
  const n = 180;
  const walk = genWalk(n, TOTALS.total_invested * 0.92, 0.012, 0.0022, 404);
  const scale = TOTALS.total_value / walk[walk.length - 1];
  const today = new Date('2026-04-18');
  return walk.map((v, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (n - 1 - i));
    return { date: d.toISOString().slice(0, 10), value: v * scale };
  });
})();

// vs S&P benchmark, both normalized to 100 at day 0
const BENCHMARK = (() => {
  const n = 180;
  const p = genWalk(n, 100, 0.011, 0.0024, 505);
  const s = genWalk(n, 100, 0.009, 0.0014, 606);
  const pScale = 100 / p[0], sScale = 100 / s[0];
  const today = new Date('2026-04-18');
  return p.map((v, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() - (n - 1 - i));
    return { date: d.toISOString().slice(0, 10), portfolio: v * pScale, sp500: s[i] * sScale };
  });
})();

// Fundamentals
const FUNDAMENTALS = POSITIONS.map(p => {
  const r = mulberry32(p.seed * 13);
  const pe        = 12 + r() * 40;
  const ev_ebitda = 8 + r() * 20;
  const ps        = 2 + r() * 10;
  const gross     = 0.32 + r() * 0.45;
  const roe       = 0.08 + r() * 0.35;
  const de        = 0.2 + r() * 1.6;
  const fcf       = 0.01 + r() * 0.07;
  // composite quality score
  const score = (roe * 100) - (de * 6) + (fcf * 200) + (gross * 30) - Math.max(0, pe - 35);
  const grade = score > 40 ? 'A' : score > 25 ? 'B' : score > 10 ? 'C' : 'D';
  return { ticker: p.ticker, name: p.name, pe, ev_ebitda, ps, gross_margin: gross, roe, debt_equity: de, fcf_yield: fcf, grade };
});

// Correlation matrix 9x9
const CORRELATION = (() => {
  const tickers = POSITIONS.map(p => p.ticker);
  const rand = mulberry32(808);
  const n = tickers.length;
  const m = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (_, j) => {
      if (i === j) return 1;
      if (i > j) return null; // fill by symmetry after
      const sameSector = POSITIONS[i].sector === POSITIONS[j].sector ? 0.25 : 0;
      return Math.max(-0.2, Math.min(0.95, 0.22 + sameSector + (rand() - 0.4) * 0.7));
    }));
  for (let i = 0; i < n; i++) for (let j = 0; j < i; j++) m[i][j] = m[j][i];
  return { tickers, matrix: m };
})();

// Stress scenarios
const SCENARIOS = [
  { id: 'gfc',       name: '2008 Financial Crisis',   desc: '−37% S&P 500 · TED spread blowout · Fed cuts to 0%',      impact_pct: -28.4 },
  { id: 'covid',     name: 'COVID-19 Shock',          desc: 'March 2020 drawdown · VIX 82 · flight-to-safety',          impact_pct: -22.1 },
  { id: 'dotcom',    name: 'Dot-com Bust',            desc: 'Nasdaq −78% over 31 months · tech multiples compress',     impact_pct: -34.6 },
  { id: 'stag',      name: 'Stagflation 2024',        desc: 'Oil +60% · CPI 8.2% · 10y yield to 6.4%',                  impact_pct: -14.8 },
  { id: 'rates',     name: '+200bps Rate Shock',      desc: 'Sudden DM hiking cycle · duration sell-off',               impact_pct: -9.2 },
  { id: 'china',     name: 'China Hard Landing',      desc: 'EM contagion · commodity collapse · export shock',         impact_pct: -11.7 },
  { id: 'ai',        name: 'AI Capex Reversal',       desc: 'Semis −40% · hyperscaler cuts · narrative break',          impact_pct: -19.3 },
  { id: 'rally',     name: 'Broad-based Rally',       desc: 'Soft landing confirmed · multiple expansion',              impact_pct: +12.6 },
];

// Efficient frontier — 60 portfolios
const FRONTIER = (() => {
  const pts = [];
  for (let i = 0; i < 60; i++) {
    const vol = 6 + i * 0.45 + (mulberry32(i + 1)() - 0.5) * 1.5;
    const ret = 2 + Math.sqrt(vol - 4) * 4.5 + (mulberry32(i + 7)() - 0.5) * 2;
    pts.push({ vol, ret });
  }
  return pts.sort((a, b) => a.vol - b.vol);
})();

// Ticker tape items
const TAPE = [
  { sym: 'S&P 500',    px: '5,318.24',  chg: '+0.42%', dir: 'pos' },
  { sym: 'NASDAQ',     px: '16,742.10', chg: '+0.81%', dir: 'pos' },
  { sym: 'DOW',        px: '39,410.77', chg: '−0.12%', dir: 'neg' },
  { sym: 'RUSSELL',    px: '2,087.44',  chg: '+0.28%', dir: 'pos' },
  { sym: 'VIX',        px: '14.82',     chg: '−3.11%', dir: 'pos' },
  { sym: 'US10Y',      px: '4.284%',    chg: '+2 bps', dir: 'neg' },
  { sym: 'DXY',        px: '102.44',    chg: '−0.18%', dir: 'pos' },
  { sym: 'BTC',        px: '$84,112',   chg: '+1.72%', dir: 'pos' },
  { sym: 'ETH',        px: '$3,284',    chg: '+0.94%', dir: 'pos' },
  { sym: 'GOLD',       px: '$2,394.1',  chg: '−0.31%', dir: 'neg' },
  { sym: 'OIL',        px: '$82.14',    chg: '+1.21%', dir: 'pos' },
  { sym: 'EUR/USD',    px: '1.0682',    chg: '+0.08%', dir: 'pos' },
];

// --- Tag fundamentals with style for filter ---
FUNDAMENTALS.forEach((f, i) => {
  // value = low P/E & low P/S, growth = high P/S & high gross, quality = high ROE & low D/E
  f.style = [];
  if (f.pe < 22) f.style.push('Value');
  if (f.ps > 6 || f.gross_margin > 0.55) f.style.push('Growth');
  if (f.roe > 0.2 && f.debt_equity < 1) f.style.push('Quality');
  if (!f.style.length) f.style.push('Core');
});

// --- Dividends (next 90d schedule) ---
const DIVIDENDS = POSITIONS.filter(p => p.dividend_yield > 0).flatMap(p => {
  const q = p.current_value * (p.dividend_yield / 100);
  const rand = mulberry32(p.seed * 17);
  return [0, 1, 2].map(k => {
    const dt = new Date('2026-04-18');
    dt.setDate(dt.getDate() + 14 + k * 30 + Math.floor(rand() * 12));
    return {
      ticker: p.ticker,
      name: p.name,
      ex_date: dt.toISOString().slice(0, 10),
      per_share: (q / 4) / p.shares,
      total: q / 4,
      color: p.color,
      frequency: 'Quarterly',
    };
  });
});

const DIVIDEND_YEAR_TOTAL = POSITIONS.reduce((s, p) => s + p.current_value * (p.dividend_yield / 100), 0);

// --- Watchlist ---
const WATCHLIST = [
  { ticker: 'GOOGL', name: 'Alphabet Class A', px: 182.44,  chg: +1.42, ytd: +18.2, mcap: '2.25T',  pe: 26.4, seed: 201 },
  { ticker: 'TSLA',  name: 'Tesla Inc.',        px: 218.77,  chg: -2.18, ytd: -12.4, mcap: '694B',   pe: 48.1, seed: 202 },
  { ticker: 'META',  name: 'Meta Platforms',    px: 512.88,  chg: +0.94, ytd: +24.7, mcap: '1.31T',  pe: 29.2, seed: 203 },
  { ticker: 'AMZN',  name: 'Amazon.com',        px: 194.22,  chg: +0.38, ytd: +8.4,  mcap: '2.02T',  pe: 51.3, seed: 204 },
  { ticker: 'NFLX',  name: 'Netflix',           px: 652.10,  chg: -0.87, ytd: +22.8, mcap: '282B',   pe: 42.6, seed: 205 },
  { ticker: 'NOVO B',name: 'Novo Nordisk',      px: 142.30,  chg: +1.92, ytd: +6.3,  mcap: '620B',   pe: 38.4, seed: 206 },
];
WATCHLIST.forEach(w => { w.spark = genWalk(30, w.px * 0.92, 0.05, 0.003, w.seed).map(v => v * w.px / genWalk(30, w.px * 0.92, 0.05, 0.003, w.seed).slice(-1)[0]); });

// --- News ---
const NEWS = [
  { t: '2h', src: 'Bloomberg', tag: 'Macro',     headline: 'Fed minutes signal patient approach as inflation glides toward 2%', impact: 'pos', tickers: ['S&P 500', 'US10Y'] },
  { t: '3h', src: 'Reuters',   tag: 'Earnings',  headline: 'NVIDIA beats Q1 on data-center demand, guides above Street', impact: 'pos', tickers: ['NVDA'] },
  { t: '5h', src: 'FT',        tag: 'Europe',    headline: 'LVMH reports mid-single-digit decline in organic growth', impact: 'neg', tickers: ['LVMH'] },
  { t: '8h', src: 'WSJ',       tag: 'Rates',     headline: '10Y yield ticks higher after strong retail-sales print', impact: 'neg', tickers: ['US10Y'] },
  { t: '1d', src: 'CNBC',      tag: 'Tech',      headline: 'ASML posts record bookings on DUV uptake in China', impact: 'pos', tickers: ['ASML'] },
  { t: '1d', src: 'Bloomberg', tag: 'Crypto',    headline: 'Bitcoin holds $84k support as ETF inflows resume', impact: 'pos', tickers: ['BTC'] },
];

// --- Trades ---
const TRADES = [
  { date: '2026-04-12', ticker: 'NVDA', side: 'BUY',  qty: 5,  px: 918.22, fee: 1.40 },
  { date: '2026-03-28', ticker: 'VWCE', side: 'BUY',  qty: 8,  px: 124.10, fee: 0.95 },
  { date: '2026-03-14', ticker: 'LVMH', side: 'SELL', qty: 2,  px: 740.00, fee: 1.20 },
  { date: '2026-02-22', ticker: 'BTC',  side: 'BUY',  qty: 0.05, px: 61200, fee: 4.20 },
  { date: '2026-01-30', ticker: 'MSFT', side: 'BUY',  qty: 10, px: 402.50, fee: 1.40 },
  { date: '2025-12-18', ticker: 'SHOP', side: 'BUY',  qty: 15, px: 72.40,  fee: 0.80 },
];

// --- Sector / Region / Country / Industry aggregators ---
function aggBy(key, palette) {
  const m = new Map();
  POSITIONS.forEach(p => {
    const k = p[key];
    if (!m.has(k)) m.set(k, { name: k, value: 0, count: 0 });
    const e = m.get(k);
    e.value += p.current_value;
    e.count += 1;
  });
  const arr = Array.from(m.values()).sort((a, b) => b.value - a.value);
  arr.forEach((d, i) => d.color = palette[i % palette.length]);
  return arr;
}

const PAL_SECTOR  = ['oklch(0.78 0.13 160)','oklch(0.72 0.12 240)','oklch(0.75 0.13 30)','oklch(0.72 0.11 110)','oklch(0.70 0.13 310)','oklch(0.76 0.12 70)','oklch(0.68 0.12 200)','oklch(0.72 0.12 50)'];
const PAL_REGION  = ['oklch(0.78 0.13 160)','oklch(0.72 0.12 260)','oklch(0.74 0.12 50)','oklch(0.68 0.12 320)'];
const PAL_COUNTRY = ['oklch(0.78 0.13 160)','oklch(0.72 0.12 240)','oklch(0.75 0.13 30)','oklch(0.72 0.11 110)','oklch(0.70 0.13 310)','oklch(0.76 0.12 70)','oklch(0.68 0.12 200)','oklch(0.72 0.12 50)'];
const PAL_TYPE    = ['oklch(0.78 0.13 160)','oklch(0.72 0.12 240)','oklch(0.75 0.13 30)','oklch(0.72 0.11 110)'];

const ALLOCATIONS = {
  position: POSITIONS.map(p => ({ name: p.ticker, full: p.name, value: p.current_value, color: p.color, meta: p.sector })),
  sector:   aggBy('sector',   PAL_SECTOR),
  industry: aggBy('industry', PAL_SECTOR),
  region:   aggBy('region',   PAL_REGION),
  country:  aggBy('country',  PAL_COUNTRY),
  type:     aggBy('type',     PAL_TYPE),
  currency: aggBy('currency', PAL_TYPE),
};

Object.assign(window, { DIVIDENDS, DIVIDEND_YEAR_TOTAL, WATCHLIST, NEWS, TRADES, ALLOCATIONS });

Object.assign(window, {
  POSITIONS, TOTALS, HISTORY, BENCHMARK, FUNDAMENTALS,
  CORRELATION, SCENARIOS, FRONTIER, TAPE, mulberry32, genWalk,
});
