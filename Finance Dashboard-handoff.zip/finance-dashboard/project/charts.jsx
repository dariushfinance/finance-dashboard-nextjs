/* global React */
// =============================================================
// charts.jsx — larger SVG charts: area, line-compare, scatter
// =============================================================

const { useState: useStateC, useMemo: useMemoC, useRef: useRefC, useEffect: useEffectC } = React;

// ---------- AreaChart ----------
function AreaChart({ data, height = 260, accessor = 'value', xKey = 'date', color = 'var(--ink)', showAxis = true, onHover }) {
  const ref = useRefC(null);
  const [w, setW] = useStateC(640);
  const [hover, setHover] = useStateC(null);

  useEffectC(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(es => setW(es[0].contentRect.width));
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);

  const { line, area, pts, min, max } = useMemoC(() => {
    if (!data || data.length < 2) return { line: '', area: '', pts: [], min: 0, max: 0 };
    const vals = data.map(d => d[accessor]);
    const mn = Math.min(...vals);
    const mx = Math.max(...vals);
    const range = mx - mn || 1;
    const padL = 50, padR = 12, padT = 16, padB = showAxis ? 26 : 8;
    const innerW = w - padL - padR;
    const innerH = height - padT - padB;
    const pts = data.map((d, i) => {
      const x = padL + (i / (data.length - 1)) * innerW;
      const y = padT + innerH - ((d[accessor] - mn) / range) * innerH;
      return { x, y, d };
    });
    const line = pts.map((p, i) => (i ? 'L' : 'M') + p.x.toFixed(2) + ',' + p.y.toFixed(2)).join(' ');
    const area = line + ` L ${pts[pts.length - 1].x.toFixed(2)},${padT + innerH} L ${pts[0].x.toFixed(2)},${padT + innerH} Z`;
    return { line, area, pts, min: mn, max: mx };
  }, [data, w, height, accessor, showAxis]);

  // Y-axis ticks
  const yTicks = useMemoC(() => {
    if (max === min) return [];
    const n = 4;
    return Array.from({ length: n + 1 }, (_, i) => {
      const v = min + (max - min) * (i / n);
      return v;
    });
  }, [min, max]);

  const handleMove = (e) => {
    const rect = ref.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    // nearest point
    let best = null, bestDx = Infinity;
    pts.forEach(p => { const dx = Math.abs(p.x - x); if (dx < bestDx) { bestDx = dx; best = p; } });
    setHover(best);
    if (onHover && best) onHover(best.d);
  };

  return (
    <div ref={ref} style={{ width: '100%', position: 'relative' }} onMouseMove={handleMove} onMouseLeave={() => setHover(null)}>
      <svg width={w} height={height} style={{ display: 'block' }}>
        <defs>
          <linearGradient id={`area-grad-${accessor}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.18" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Y grid */}
        {showAxis && yTicks.map((v, i) => {
          const y = 16 + (height - 42) - ((v - min) / (max - min || 1)) * (height - 42);
          return (
            <g key={i}>
              <line x1={50} x2={w - 12} y1={y} y2={y} stroke="var(--line-soft)" strokeDasharray="2 4" />
              <text x={42} y={y + 3} fontSize="10" fill="var(--ink-4)" textAnchor="end" fontFamily="var(--font-mono)">
                {fmt.moneyCompact(v)}
              </text>
            </g>
          );
        })}

        {/* X axis labels */}
        {showAxis && pts.length > 0 && [0, Math.floor(pts.length * 0.25), Math.floor(pts.length * 0.5), Math.floor(pts.length * 0.75), pts.length - 1].map((i, k) => (
          <text key={k} x={pts[i].x} y={height - 8} fontSize="10" fill="var(--ink-4)" textAnchor="middle" fontFamily="var(--font-mono)">
            {pts[i].d[xKey]?.slice(5) ?? ''}
          </text>
        ))}

        <path d={area} fill={`url(#area-grad-${accessor})`} />
        <path d={line} fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />

        {hover && (
          <g>
            <line x1={hover.x} x2={hover.x} y1={16} y2={height - 26} stroke="var(--ink-4)" strokeDasharray="2 3" />
            <circle cx={hover.x} cy={hover.y} r={6} fill={color} opacity={0.2} />
            <circle cx={hover.x} cy={hover.y} r={3.5} fill={color} stroke="var(--bg-1)" strokeWidth="2" />
          </g>
        )}
      </svg>

      {hover && (
        <div style={{
          position: 'absolute',
          left: Math.min(hover.x + 12, w - 170),
          top: Math.max(hover.y - 40, 8),
          background: 'var(--bg-2)',
          border: '1px solid var(--line)',
          borderRadius: 8,
          padding: '7px 11px',
          fontSize: 11,
          fontFamily: 'var(--font-mono)',
          boxShadow: 'var(--shadow-hi)',
          pointerEvents: 'none',
          whiteSpace: 'nowrap',
        }}>
          <div style={{ color: 'var(--ink-4)', fontSize: 10 }}>{hover.d[xKey]}</div>
          <div style={{ color: 'var(--ink)', fontWeight: 600, marginTop: 2 }}>
            ${fmt.money(hover.d[accessor])}
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- Compare chart (portfolio vs benchmark) ----------
function CompareChart({ data, height = 300 }) {
  const ref = useRefC(null);
  const [w, setW] = useStateC(640);
  const [hover, setHover] = useStateC(null);

  useEffectC(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(es => setW(es[0].contentRect.width));
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);

  const { pLine, pArea, sLine, pts, min, max } = useMemoC(() => {
    if (!data || data.length < 2) return { pLine: '', pArea: '', sLine: '', pts: [], min: 0, max: 0 };
    const all = data.flatMap(d => [d.portfolio, d.sp500]);
    const mn = Math.min(...all);
    const mx = Math.max(...all);
    const range = mx - mn || 1;
    const padL = 50, padR = 12, padT = 16, padB = 28;
    const innerW = w - padL - padR, innerH = height - padT - padB;
    const toPt = (v, i) => ({
      x: padL + (i / (data.length - 1)) * innerW,
      y: padT + innerH - ((v - mn) / range) * innerH,
    });
    const pPts = data.map((d, i) => toPt(d.portfolio, i));
    const sPts = data.map((d, i) => toPt(d.sp500, i));
    const toLine = (pts) => pts.map((p, i) => (i ? 'L' : 'M') + p.x.toFixed(2) + ',' + p.y.toFixed(2)).join(' ');
    const pLine = toLine(pPts);
    const sLine = toLine(sPts);
    const pArea = pLine + ` L ${pPts[pPts.length - 1].x},${padT + innerH} L ${pPts[0].x},${padT + innerH} Z`;
    return { pLine, pArea, sLine, pts: pPts, min: mn, max: mx };
  }, [data, w, height]);

  const handleMove = (e) => {
    const rect = ref.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    let bestIdx = 0, bestDx = Infinity;
    pts.forEach((p, i) => { const dx = Math.abs(p.x - x); if (dx < bestDx) { bestDx = dx; bestIdx = i; } });
    setHover(bestIdx);
  };

  return (
    <div ref={ref} style={{ width: '100%', position: 'relative' }} onMouseMove={handleMove} onMouseLeave={() => setHover(null)}>
      <svg width={w} height={height} style={{ display: 'block' }}>
        <defs>
          <linearGradient id="portfolio-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--pos)" stopOpacity="0.18" />
            <stop offset="100%" stopColor="var(--pos)" stopOpacity="0" />
          </linearGradient>
        </defs>
        {/* baseline 100 line */}
        {data && data.length > 0 && (() => {
          const y = 16 + (height - 44) - ((100 - min) / (max - min || 1)) * (height - 44);
          return <line x1={50} x2={w - 12} y1={y} y2={y} stroke="var(--line)" strokeDasharray="4 4" />;
        })()}
        {/* y grid */}
        {[0, 0.25, 0.5, 0.75, 1].map((t, i) => {
          const v = min + (max - min) * t;
          const y = 16 + (height - 44) - ((v - min) / (max - min || 1)) * (height - 44);
          return (
            <g key={i}>
              <text x={42} y={y + 3} fontSize="10" fill="var(--ink-4)" textAnchor="end" fontFamily="var(--font-mono)">{v.toFixed(0)}</text>
            </g>
          );
        })}
        <path d={pArea} fill="url(#portfolio-grad)" />
        <path d={sLine} fill="none" stroke="var(--ink-3)" strokeWidth="1.4" strokeDasharray="3 3" />
        <path d={pLine} fill="none" stroke="var(--pos)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />

        {hover != null && pts[hover] && (
          <g>
            <line x1={pts[hover].x} x2={pts[hover].x} y1={16} y2={height - 28} stroke="var(--ink-4)" strokeDasharray="2 3" />
            <circle cx={pts[hover].x} cy={pts[hover].y} r={4} fill="var(--pos)" stroke="var(--bg-1)" strokeWidth="2" />
          </g>
        )}

        {/* X axis */}
        {pts && pts.length > 0 && [0, Math.floor(pts.length * 0.25), Math.floor(pts.length * 0.5), Math.floor(pts.length * 0.75), pts.length - 1].map((i, k) => (
          <text key={k} x={pts[i].x} y={height - 8} fontSize="10" fill="var(--ink-4)" textAnchor="middle" fontFamily="var(--font-mono)">
            {data[i].date.slice(5)}
          </text>
        ))}
      </svg>

      {hover != null && data[hover] && (
        <div style={{
          position: 'absolute',
          left: Math.min(pts[hover].x + 12, w - 200), top: 16,
          background: 'var(--bg-2)', border: '1px solid var(--line)', borderRadius: 8,
          padding: '8px 12px', fontSize: 11, fontFamily: 'var(--font-mono)',
          boxShadow: 'var(--shadow-hi)', pointerEvents: 'none', minWidth: 160,
        }}>
          <div style={{ color: 'var(--ink-4)', fontSize: 10, marginBottom: 4 }}>{data[hover].date}</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--pos)' }}>
            <span>Portfolio</span><span>{data[hover].portfolio.toFixed(2)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--ink-3)' }}>
            <span>S&amp;P 500</span><span>{data[hover].sp500.toFixed(2)}</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- Scatter (Efficient Frontier) ----------
function ScatterChart({ points, height = 340, currentPortfolio, optimal }) {
  const ref = useRefC(null);
  const [w, setW] = useStateC(640);
  useEffectC(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(es => setW(es[0].contentRect.width));
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);

  const { scaled, envelope, cur, opt } = useMemoC(() => {
    if (!points || !points.length) return { scaled: [], envelope: '' };
    const minV = Math.min(...points.map(p => p.vol));
    const maxV = Math.max(...points.map(p => p.vol));
    const minR = Math.min(...points.map(p => p.ret));
    const maxR = Math.max(...points.map(p => p.ret));
    const padL = 50, padR = 16, padT = 16, padB = 36;
    const innerW = w - padL - padR, innerH = height - padT - padB;
    const scaleX = v => padL + ((v - minV) / (maxV - minV)) * innerW;
    const scaleY = r => padT + innerH - ((r - minR) / (maxR - minR)) * innerH;
    const scaled = points.map(p => ({ ...p, x: scaleX(p.vol), y: scaleY(p.ret) }));
    // envelope = smooth upper hull-ish path along frontier
    const envelope = scaled.map((p, i) => (i ? 'L' : 'M') + p.x.toFixed(1) + ',' + p.y.toFixed(1)).join(' ');
    const cur = currentPortfolio ? { x: scaleX(currentPortfolio.vol), y: scaleY(currentPortfolio.ret) } : null;
    const opt = optimal ? { x: scaleX(optimal.vol), y: scaleY(optimal.ret) } : null;
    return { scaled, envelope, cur, opt, minV, maxV, minR, maxR };
  }, [points, w, height, currentPortfolio, optimal]);

  return (
    <div ref={ref} style={{ width: '100%', position: 'relative' }}>
      <svg width={w} height={height}>
        {/* grid */}
        {[0, 0.25, 0.5, 0.75, 1].map((t, i) => {
          const y = 16 + (height - 52) * (1 - t);
          return <line key={i} x1={50} x2={w - 16} y1={y} y2={y} stroke="var(--line-soft)" strokeDasharray="2 4" />;
        })}
        <path d={envelope} fill="none" stroke="var(--pos)" strokeWidth="1.25" strokeOpacity="0.4" strokeDasharray="3 3" />
        {scaled.map((p, i) => (
          <circle key={i} cx={p.x} cy={p.y} r={2.8} fill="var(--ink-4)" opacity={0.55} />
        ))}
        {cur && (
          <g>
            <circle cx={cur.x} cy={cur.y} r={10} fill="var(--neg)" opacity={0.18} />
            <circle cx={cur.x} cy={cur.y} r={5} fill="var(--neg)" stroke="var(--bg-1)" strokeWidth="2" />
            <text x={cur.x + 10} y={cur.y + 4} fontSize="10.5" fill="var(--neg)" fontFamily="var(--font-mono)" fontWeight="600">You</text>
          </g>
        )}
        {opt && (
          <g>
            <circle cx={opt.x} cy={opt.y} r={11} fill="var(--pos)" opacity={0.18} />
            <circle cx={opt.x} cy={opt.y} r={6} fill="var(--pos)" stroke="var(--bg-1)" strokeWidth="2" />
            <text x={opt.x + 11} y={opt.y + 4} fontSize="10.5" fill="var(--pos)" fontFamily="var(--font-mono)" fontWeight="600">Optimal</text>
          </g>
        )}
        {/* axis labels */}
        <text x={w / 2} y={height - 6} fontSize="10" fill="var(--ink-4)" textAnchor="middle" fontFamily="var(--font-mono)" letterSpacing="0.1em">VOLATILITY (%)</text>
        <text x={14} y={height / 2} fontSize="10" fill="var(--ink-4)" textAnchor="middle" fontFamily="var(--font-mono)" letterSpacing="0.1em" transform={`rotate(-90 14 ${height / 2})`}>EXPECTED RETURN (%)</text>
      </svg>
    </div>
  );
}

// ---------- Donut chart ----------
function Donut({ data, size = 220, thickness = 24 }) {
  const total = data.reduce((s, d) => s + d.value, 0);
  const r = size / 2 - thickness / 2;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <g transform={`translate(${size / 2},${size / 2}) rotate(-90)`}>
        <circle cx={0} cy={0} r={r} fill="none" stroke="var(--bg-3)" strokeWidth={thickness} />
        {data.map((d, i) => {
          const frac = d.value / total;
          const len = frac * c;
          const el = (
            <circle key={i} cx={0} cy={0} r={r} fill="none"
                    stroke={d.color} strokeWidth={thickness}
                    strokeDasharray={`${len} ${c - len}`}
                    strokeDashoffset={-offset}
                    style={{ transition: 'stroke-dasharray 0.4s ease' }}
            />
          );
          offset += len;
          // add small gap
          offset += 1.5;
          return el;
        })}
      </g>
    </svg>
  );
}

Object.assign(window, { AreaChart, CompareChart, ScatterChart, Donut });
