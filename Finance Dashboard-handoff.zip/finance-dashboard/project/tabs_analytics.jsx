/* global React */
// =============================================================
// tabs_analytics.jsx — Benchmark + Fundamentals
// =============================================================

function BenchmarkTab() {
  const { beta, alpha, information_ratio } = TOTALS;
  const [range, setRange] = React.useState('6M');
  const cuts = { '1M': 30, '3M': 90, '6M': 180, 'YTD': 180, '1Y': 180 };
  const data = BENCHMARK.slice(-cuts[range]);
  const pEnd = data[data.length - 1].portfolio;
  const sEnd = data[data.length - 1].sp500;
  const pStart = data[0].portfolio;
  const sStart = data[0].sp500;
  const pRet = ((pEnd / pStart) - 1) * 100;
  const sRet = ((sEnd / sStart) - 1) * 100;
  const outperf = pRet - sRet;

  return (
    <>
      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Portfolio vs. S&amp;P 500</div>
            <div className="card__sub">Normalized to 100 at period start · total return</div>
          </div>
          <div className="chip-group">
            {['1M','3M','6M','YTD','1Y'].map(r => (
              <button key={r} className={range === r ? 'active' : ''} onClick={() => setRange(r)}>{r}</button>
            ))}
          </div>
        </div>
        <div className="chart-legend">
          <div className="chart-legend__item">
            <span className="chart-legend__swatch" style={{ background: 'var(--pos)' }} />
            My portfolio · <strong className="mono" style={{ color: 'var(--ink)' }}>{fmt.pct(pRet)}</strong>
          </div>
          <div className="chart-legend__item">
            <span className="chart-legend__swatch" style={{ background: 'var(--ink-3)', borderStyle: 'dashed' }} />
            S&amp;P 500 · <span className="mono">{fmt.pct(sRet)}</span>
          </div>
          <div className="chart-legend__item" style={{ marginLeft: 'auto' }}>
            <span style={{ color: 'var(--ink-4)', fontSize: 11 }}>Outperformance</span>
            <span className={`mono ${outperf >= 0 ? 'pos' : 'neg'}`} style={{ fontWeight: 600 }}>{fmt.pct(outperf)}</span>
          </div>
        </div>
        <div className="chart-wrap" style={{ paddingTop: 0 }}>
          <CompareChart data={data} height={320} />
        </div>
        <div className="stat-strip">
          <div>
            <div className="chart-stat__label">Beta (vs S&amp;P)</div>
            <div className="chart-stat__val">{beta.toFixed(2)}</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 2 }}>Slightly above market risk</div>
          </div>
          <div>
            <div className="chart-stat__label">Alpha (annualized)</div>
            <div className="chart-stat__val pos">+{alpha.toFixed(2)}%</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 2 }}>Excess return over benchmark</div>
          </div>
          <div>
            <div className="chart-stat__label">Information ratio</div>
            <div className="chart-stat__val">{information_ratio.toFixed(2)}</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 2 }}>Consistency of outperformance</div>
          </div>
          <div>
            <div className="chart-stat__label">R² (fit)</div>
            <div className="chart-stat__val">0.78</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 2 }}>Strong correlation</div>
          </div>
          <div>
            <div className="chart-stat__label">Tracking error</div>
            <div className="chart-stat__val">5.7%</div>
            <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 2 }}>Active deviation</div>
          </div>
        </div>
      </div>

      <div className="two-col">
        <div className="card">
          <div className="card__head">
            <div className="card__title">Rolling 60-day beta</div>
          </div>
          <div className="chart-wrap">
            <AreaChart
              data={data.map((d, i) => ({ date: d.date, value: 0.9 + Math.sin(i / 14) * 0.25 + (i / data.length) * 0.15 }))}
              height={220} accessor="value" color="var(--info)" />
          </div>
        </div>
        <div className="card">
          <div className="card__head">
            <div className="card__title">Rolling excess return</div>
            <div className="card__sub">Portfolio − benchmark, 60-day</div>
          </div>
          <div className="chart-wrap">
            <AreaChart
              data={data.map((d, i) => ({ date: d.date, value: (d.portfolio - d.sp500) }))}
              height={220} accessor="value" color="var(--pos)" />
          </div>
        </div>
      </div>
    </>
  );
}

function FundamentalsTab() {
  const [sort, setSort] = React.useState({ key: 'grade', dir: 'asc' });
  const [filter, setFilter] = React.useState('All');
  const filtered = FUNDAMENTALS.filter(f => filter === 'All' || f.style.includes(filter));
  const rows = [...filtered].sort((a, b) => {
    const av = a[sort.key], bv = b[sort.key];
    const cmp = typeof av === 'string' ? av.localeCompare(bv) : av - bv;
    return sort.dir === 'asc' ? cmp : -cmp;
  });

  const SortHead = ({ k, children, align }) => (
    <th className={align === 'right' ? 'num' : ''}
        style={{ cursor: 'pointer', userSelect: 'none' }}
        onClick={() => setSort(s => ({ key: k, dir: s.key === k && s.dir === 'asc' ? 'desc' : 'asc' }))}>
      {children}{sort.key === k ? (sort.dir === 'asc' ? ' ↑' : ' ↓') : ''}
    </th>
  );

  const gradeCls = { A: 'a', B: 'b', C: 'c', D: 'd' };
  const FILTERS = ['All', 'Value', 'Growth', 'Quality'];

  return (
    <div className="card">
      <div className="card__head">
        <div>
          <div className="card__title">Company fundamentals</div>
          <div className="card__sub">Valuation, profitability &amp; leverage metrics · {rows.length} of {FUNDAMENTALS.length} shown</div>
        </div>
        <div className="chip-group">
          {FILTERS.map(f => (
            <button key={f} className={filter === f ? 'active' : ''} onClick={() => setFilter(f)}>{f}</button>
          ))}
        </div>
      </div>
      <div className="tbl-wrap">
        <table className="tbl fund-tbl">
          <thead>
            <tr>
              <SortHead k="ticker">Symbol</SortHead>
              <SortHead k="grade">Quality</SortHead>
              <SortHead k="pe" align="right">P/E</SortHead>
              <SortHead k="ev_ebitda" align="right">EV/EBITDA</SortHead>
              <SortHead k="ps" align="right">P/S</SortHead>
              <SortHead k="gross_margin" align="right">Gross margin</SortHead>
              <SortHead k="roe" align="right">ROE</SortHead>
              <SortHead k="debt_equity" align="right">D/E</SortHead>
              <SortHead k="fcf_yield" align="right">FCF yield</SortHead>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => {
              const pos = POSITIONS.find(p => p.ticker === r.ticker);
              return (
                <tr key={r.ticker}>
                  <td>
                    <div className="sym">
                      <TickerMark p={pos} />
                      <div>
                        <div className="sym__ticker">{r.ticker}</div>
                        <div className="sym__name">{r.name}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`score-pill score-pill--${gradeCls[r.grade]}`}>{r.grade}</span>
                  </td>
                  <td className="num">{r.pe.toFixed(1)}</td>
                  <td className="num">{r.ev_ebitda.toFixed(1)}</td>
                  <td className="num">{r.ps.toFixed(2)}</td>
                  <td className="num">{(r.gross_margin * 100).toFixed(1)}%</td>
                  <td className={`num ${r.roe > 0.2 ? 'pos' : ''}`}>{(r.roe * 100).toFixed(1)}%</td>
                  <td className={`num ${r.debt_equity > 1 ? 'neg' : ''}`}>{r.debt_equity.toFixed(2)}</td>
                  <td className="num">{(r.fcf_yield * 100).toFixed(2)}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

Object.assign(window, { BenchmarkTab, FundamentalsTab });
