/* global React */
// =============================================================
// tabs_overview.jsx — Overview + History tabs
// =============================================================

function HeroBlock({ onAdd }) {
  const { total_value, total_invested, total_pnl, total_return, day_change, day_change_pct, sharpe, max_drawdown } = TOTALS;
  const [range, setRange] = React.useState('6M');

  const data = React.useMemo(() => {
    const cuts = { '1W': 7, '1M': 30, '3M': 90, '6M': 180, '1Y': 180, 'ALL': 180 };
    return HISTORY.slice(-cuts[range]);
  }, [range]);

  const intStr = Math.floor(total_value).toLocaleString('en-US');
  const decStr = (total_value % 1).toFixed(2).slice(1);

  return (
    <section className="hero">
      <div className="hero__grid">
        <div className="hero__left">
          <div className="hero__eyebrow">Total portfolio value · USD</div>
          <div className="hero__value">
            <span className="cur">$</span>{intStr}<span className="dec">{decStr}</span>
          </div>
          <div className="hero__delta">
            <Delta value={day_change_pct} />
            <span className="delta-muted mono">
              {day_change >= 0 ? '+' : '−'}${fmt.money(Math.abs(day_change))} today
            </span>
          </div>

          <div className="hero__meta">
            <div className="hero__meta-item">
              <div className="hero__meta-label">All-time P&amp;L</div>
              <div className={`hero__meta-val ${total_pnl >= 0 ? 'pos' : 'neg'}`}>
                {total_pnl >= 0 ? '+' : '−'}${fmt.money(Math.abs(total_pnl))}
              </div>
            </div>
            <div className="hero__meta-item">
              <div className="hero__meta-label">Total return</div>
              <div className={`hero__meta-val ${total_return >= 0 ? 'pos' : 'neg'}`}>{fmt.pct(total_return)}</div>
            </div>
            <div className="hero__meta-item">
              <div className="hero__meta-label">Sharpe</div>
              <div className="hero__meta-val">{sharpe.toFixed(2)}</div>
            </div>
            <div className="hero__meta-item">
              <div className="hero__meta-label">Max drawdown</div>
              <div className="hero__meta-val neg">{max_drawdown.toFixed(1)}%</div>
            </div>
            <div className="hero__meta-item">
              <div className="hero__meta-label">Invested</div>
              <div className="hero__meta-val">${fmt.money(total_invested, 0)}</div>
            </div>
          </div>
        </div>

        <div className="hero__right">
          <div className="hero__spark-head">
            <div className="hero__spark-title">Portfolio value</div>
            <div className="hero__spark-tabs">
              {['1W','1M','3M','6M','1Y','ALL'].map(r => (
                <button key={r} onClick={() => setRange(r)}
                        className={`hero__spark-tab ${range === r ? 'hero__spark-tab--active' : ''}`}>{r}</button>
              ))}
            </div>
          </div>
          <div style={{ flex: 1, minHeight: 0 }}>
            <AreaChart data={data} height={160} accessor="value" color="var(--pos)" showAxis={false} />
          </div>
          <div className="hero__range">
            <span>{data[0]?.date}</span>
            <span>{data[data.length - 1]?.date}</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function MetricsRow() {
  const { total_value, total_pnl, total_return, day_change_pct, sharpe, volatility } = TOTALS;
  const spark = HISTORY.slice(-30).map(h => h.value);

  const cards = [
    { label: 'Net liquidation', val: total_value, prefix: '$', deltaPct: day_change_pct, deltaLabel: 'today', spark, color: 'var(--pos)' },
    { label: 'Unrealized P&L',  val: total_pnl,   prefix: total_pnl >= 0 ? '+$' : '−$', absVal: true, deltaPct: total_return, deltaLabel: 'all-time', spark, color: total_pnl >= 0 ? 'var(--pos)' : 'var(--neg)' },
    { label: 'Sharpe ratio',    val: sharpe,      prefix: '',  fixed: 2, note: 'Annualized', rating: 'Excellent', color: 'var(--pos)' },
    { label: 'Volatility',      val: volatility,  prefix: '',  fixed: 1, suffix: '%', note: '30-day annualized', rating: 'Moderate', color: 'var(--ink-3)' },
  ];

  return (
    <div className="metrics">
      {cards.map((c, i) => {
        const valStr = c.fixed != null
          ? c.val.toFixed(c.fixed)
          : fmt.money(c.absVal ? Math.abs(c.val) : c.val, 2);
        return (
          <div key={i} className="metric">
            <div className="metric__label">{c.label}</div>
            <div className="metric__val">
              {c.prefix && <span className="cur">{c.prefix}</span>}{valStr}{c.suffix || ''}
            </div>
            <div className="metric__sub">
              {c.deltaPct != null && (
                <>
                  <span className={`chg ${c.deltaPct >= 0 ? 'pos' : 'neg'}`}>
                    {c.deltaPct >= 0 ? '▲' : '▼'} {Math.abs(c.deltaPct).toFixed(2)}%
                  </span>
                  <span style={{ color: 'var(--ink-4)' }}>{c.deltaLabel}</span>
                </>
              )}
              {c.note && <span style={{ color: 'var(--ink-4)' }}>{c.note} · <span style={{ color: c.color }}>{c.rating}</span></span>}
            </div>
            {c.spark && (
              <div className="metric__spark">
                <Sparkline data={c.spark} width={80} height={28} stroke={c.color} fill={`color-mix(in oklch, ${c.color} 18%, transparent)`} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function PortfolioTable({ onDelete }) {
  return (
    <div className="card">
      <div className="card__head">
        <div>
          <div className="card__title">Holdings</div>
          <div className="card__sub">{POSITIONS.length} positions · live pricing from Alpha Vantage</div>
        </div>
        <div className="card__actions">
          <div className="chip-group">
            <button className="active">All</button>
            <button>Gainers</button>
            <button>Losers</button>
          </div>
          <button className="btn btn--ghost" style={{ padding: '6px 10px' }}>
            {Icons.download}<span>Export</span>
          </button>
        </div>
      </div>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>Symbol</th>
              <th className="num">Shares</th>
              <th className="num">Avg cost</th>
              <th className="num">Last</th>
              <th>30-day</th>
              <th className="num">Market value</th>
              <th className="num">Unrealized P&amp;L</th>
              <th className="num">Today</th>
              <th style={{ width: 40 }}></th>
            </tr>
          </thead>
          <tbody>
            {POSITIONS.map(p => (
              <tr key={p.id}>
                <td>
                  <div className="sym">
                    <TickerMark p={p} />
                    <div>
                      <div className="sym__ticker">{p.ticker}</div>
                      <div className="sym__name">{p.name}</div>
                    </div>
                  </div>
                </td>
                <td className="num">{p.shares}</td>
                <td className="num">${fmt.money(p.buy_price)}</td>
                <td className="num" style={{ color: 'var(--ink)' }}>${fmt.money(p.current_price)}</td>
                <td><Sparkline data={p.spark} width={72} height={24} /></td>
                <td className="num" style={{ color: 'var(--ink)' }}>${fmt.money(p.current_value)}</td>
                <td className={`num ${p.pnl >= 0 ? 'pos' : 'neg'}`}>
                  {p.pnl >= 0 ? '+' : '−'}${fmt.money(Math.abs(p.pnl))}
                  <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 2 }}>
                    {fmt.pct(p.return_pct)}
                  </div>
                </td>
                <td className={`num ${p.day_change_pct >= 0 ? 'pos' : 'neg'}`}>
                  {fmt.pct(p.day_change_pct)}
                </td>
                <td>
                  <button className="row-action" title="Remove" onClick={() => onDelete(p.id)}>{Icons.trash}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AllocationCard() {
  const [view, setView] = React.useState('position');
  const [chart, setChart] = React.useState('donut');
  const data = ALLOCATIONS[view];
  const total = data.reduce((s, d) => s + d.value, 0);
  const top = [...data].sort((a, b) => b.value - a.value)[0];

  const VIEWS = [
    { id: 'position', label: 'Positions' },
    { id: 'sector',   label: 'Sectors' },
    { id: 'industry', label: 'Industries' },
    { id: 'region',   label: 'Regions' },
    { id: 'country',  label: 'Countries' },
    { id: 'type',     label: 'Asset type' },
    { id: 'currency', label: 'Currency' },
  ];
  const CHARTS = [
    { id: 'donut',    label: 'Donut' },
    { id: 'treemap',  label: 'Treemap' },
    { id: 'bars',     label: 'Bars' },
    { id: 'stacked',  label: 'Stacked' },
  ];

  return (
    <div className="card">
      <div className="card__head">
        <div>
          <div className="card__title">Allocation</div>
          <div className="card__sub">Portfolio weight by {VIEWS.find(v => v.id === view).label.toLowerCase()}</div>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <div className="chip-group">
            {VIEWS.map(v => (
              <button key={v.id} className={view === v.id ? 'active' : ''} onClick={() => setView(v.id)}>{v.label}</button>
            ))}
          </div>
          <div className="chip-group">
            {CHARTS.map(c => (
              <button key={c.id} className={chart === c.id ? 'active' : ''} onClick={() => setChart(c.id)}>{c.label}</button>
            ))}
          </div>
        </div>
      </div>

      {chart === 'donut' && (
        <div className="allocation">
          <div className="donut-wrap">
            <Donut data={data} size={220} thickness={22} />
            <div className="donut-center">
              <div className="donut-center__label">Largest</div>
              <div className="donut-center__val">{top.name}</div>
              <div className="donut-center__sub">{((top.value / total) * 100).toFixed(1)}% · ${fmt.moneyCompact(top.value)}</div>
            </div>
          </div>
          <div className="alloc-list">
            {data.map(d => {
              const pct = (d.value / total) * 100;
              return (
                <div key={d.name} className="alloc-row">
                  <div className="alloc-row__dot" style={{ background: d.color }} />
                  <div>
                    <div className="alloc-row__name">{d.name}</div>
                    {d.meta && <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 1 }}>{d.meta}</div>}
                    {d.count != null && <div style={{ fontSize: 10.5, color: 'var(--ink-4)', marginTop: 1 }}>{d.count} position{d.count > 1 ? 's' : ''}</div>}
                  </div>
                  <div className="alloc-row__val">${fmt.moneyCompact(d.value)}</div>
                  <div className="alloc-row__pct">{pct.toFixed(1)}%</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {chart === 'treemap' && (
        <div style={{ padding: 20 }}>
          <TreemapChart data={data} width={900} height={360} />
        </div>
      )}

      {chart === 'bars' && (
        <div style={{ padding: 20 }}>
          <HBarChart data={data} height={340} />
        </div>
      )}

      {chart === 'stacked' && (
        <div style={{ padding: 24 }}>
          <StackedBar data={data} height={44} />
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, marginTop: 18 }}>
            {data.map(d => {
              const pct = (d.value / total) * 100;
              return (
                <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12 }}>
                  <span style={{ width: 10, height: 10, borderRadius: 3, background: d.color }} />
                  <span style={{ color: 'var(--ink)', fontWeight: 500 }}>{d.name}</span>
                  <span style={{ color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>{pct.toFixed(1)}%</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function OverviewTab({ onAdd, onDelete }) {
  return (
    <>
      <HeroBlock onAdd={onAdd} />
      <MetricsRow />
      <div className="spacer-16" />
      <PortfolioTable onDelete={onDelete} />
      <div className="spacer-16" />
      <AllocationCard />
    </>
  );
}

function HistoryTab() {
  const [range, setRange] = React.useState('6M');
  const cuts = { '1M': 30, '3M': 90, '6M': 180, '1Y': 180, 'ALL': 180 };
  const data = HISTORY.slice(-cuts[range]);
  const first = data[0].value, last = data[data.length - 1].value;
  const ret = ((last / first) - 1) * 100;

  return (
    <>
      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Portfolio history</div>
            <div className="card__sub">Daily net liquidation value</div>
          </div>
          <div className="chip-group">
            {['1M','3M','6M','1Y','ALL'].map(r => (
              <button key={r} className={range === r ? 'active' : ''} onClick={() => setRange(r)}>{r}</button>
            ))}
          </div>
        </div>
        <div className="chart-wrap">
          <AreaChart data={data} height={320} accessor="value" color={ret >= 0 ? 'var(--pos)' : 'var(--neg)'} />
        </div>
        <div className="stat-strip">
          <div>
            <div className="chart-stat__label">Start value</div>
            <div className="chart-stat__val">${fmt.money(first, 0)}</div>
          </div>
          <div>
            <div className="chart-stat__label">End value</div>
            <div className="chart-stat__val">${fmt.money(last, 0)}</div>
          </div>
          <div>
            <div className="chart-stat__label">Period return</div>
            <div className={`chart-stat__val ${ret >= 0 ? 'pos' : 'neg'}`}>{fmt.pct(ret)}</div>
          </div>
          <div>
            <div className="chart-stat__label">Best day</div>
            <div className="chart-stat__val pos">+2.14%</div>
          </div>
          <div>
            <div className="chart-stat__label">Worst day</div>
            <div className="chart-stat__val neg">−1.92%</div>
          </div>
        </div>
      </div>

      <div className="two-col">
        <div className="card">
          <div className="card__head">
            <div className="card__title">Cumulative return</div>
          </div>
          <div className="chart-wrap">
            <AreaChart
              data={data.map(d => ({ date: d.date, value: ((d.value / first) - 1) * 100 }))}
              height={240} accessor="value"
              color={ret >= 0 ? 'var(--pos)' : 'var(--neg)'} />
          </div>
        </div>
        <div className="card">
          <div className="card__head">
            <div className="card__title">Daily returns</div>
            <div className="card__sub">Distribution</div>
          </div>
          <div className="chart-wrap" style={{ height: 240, display: 'flex', alignItems: 'flex-end', gap: 2, padding: '22px 22px 26px' }}>
            {Array.from({ length: 21 }, (_, i) => {
              const h = 30 + Math.abs(Math.sin(i * 1.7)) * 140 + (i === 10 ? 30 : 0);
              const center = i >= 9 && i <= 11;
              return (
                <div key={i} style={{
                  flex: 1, height: h,
                  background: center ? 'var(--ink-3)' : i < 10 ? 'var(--neg-line)' : 'var(--pos-line)',
                  borderRadius: '2px 2px 0 0',
                  opacity: 0.85,
                }} />
              );
            })}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0 22px 14px', fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--ink-4)' }}>
            <span>−3%</span><span>0</span><span>+3%</span>
          </div>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { OverviewTab, HistoryTab });
