/* global React */
// tabs_extra.jsx — Dividends, Markets, Cashflows, Hedging (Black-Scholes)

const { useState: usX, useMemo: umX } = React;

// =============================================================
// DIVIDENDS TAB
// =============================================================
function DividendsTab() {
  const yearTotal = DIVIDEND_YEAR_TOTAL;
  const monthly = yearTotal / 12;
  const yieldPct = (yearTotal / TOTALS.total_value) * 100;

  // group dividends by month
  const byMonth = umX(() => {
    const m = {};
    DIVIDENDS.forEach(d => {
      const key = d.ex_date.slice(0, 7);
      if (!m[key]) m[key] = [];
      m[key].push(d);
    });
    return m;
  }, []);

  // 12-month projected stream
  const months = Array.from({ length: 12 }, (_, i) => {
    const d = new Date('2026-04-01');
    d.setMonth(d.getMonth() + i);
    const key = d.toISOString().slice(0, 7);
    const items = byMonth[key] || [];
    const total = items.reduce((s, it) => s + it.total, 0) || monthly * (0.6 + (i % 3) * 0.3);
    return { key, label: d.toLocaleString('en-US', { month: 'short' }), total, items };
  });
  const maxM = Math.max(...months.map(m => m.total));

  // per-position dividend contribution
  const contributors = POSITIONS
    .filter(p => p.dividend_yield > 0)
    .map(p => ({ ticker: p.ticker, name: p.name, color: p.color, annual: p.current_value * p.dividend_yield / 100, yield: p.dividend_yield }))
    .sort((a, b) => b.annual - a.annual);
  const contribTotal = contributors.reduce((s, c) => s + c.annual, 0);

  return (
    <>
      <div className="three-col">
        <div className="metric">
          <div className="metric__label">Projected 12-mo income</div>
          <div className="metric__val"><span className="cur">$</span>{fmt.money(yearTotal, 0)}</div>
          <div className="metric__sub"><span className="chg pos">▲ 8.4%</span><span style={{ color: 'var(--ink-4)' }}>vs last 12mo</span></div>
        </div>
        <div className="metric">
          <div className="metric__label">Portfolio yield</div>
          <div className="metric__val">{yieldPct.toFixed(2)}<span style={{ color: 'var(--ink-3)', fontWeight: 500 }}>%</span></div>
          <div className="metric__sub"><span style={{ color: 'var(--ink-4)' }}>TTM · {contributors.length} payers</span></div>
        </div>
        <div className="metric">
          <div className="metric__label">Avg. monthly</div>
          <div className="metric__val"><span className="cur">$</span>{fmt.money(monthly, 0)}</div>
          <div className="metric__sub"><span style={{ color: 'var(--ink-4)' }}>≈ ${(monthly / 30).toFixed(0)} / day</span></div>
        </div>
      </div>

      <div className="spacer-20" />

      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Dividend calendar · next 12 months</div>
            <div className="card__sub">Projected payments based on current yield &amp; frequency</div>
          </div>
          <div className="chip-group">
            <button className="active">12M</button>
            <button>24M</button>
            <button>36M</button>
          </div>
        </div>
        <div style={{ padding: '20px 22px 22px', display: 'flex', alignItems: 'flex-end', gap: 8, height: 200 }}>
          {months.map(m => {
            const h = (m.total / maxM) * 140 + 10;
            return (
              <div key={m.key} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--ink)', fontWeight: 600 }}>
                  ${fmt.moneyCompact(m.total)}
                </div>
                <div style={{
                  width: '100%', height: h, background: 'linear-gradient(180deg, var(--pos) 0%, color-mix(in oklch, var(--pos) 40%, transparent) 100%)',
                  borderRadius: '6px 6px 0 0', minWidth: 16,
                  boxShadow: 'inset 0 1px 0 oklch(1 0 0 / 0.15)',
                }} />
                <div style={{ fontSize: 10.5, color: 'var(--ink-4)', fontFamily: 'var(--font-mono)' }}>{m.label}</div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="spacer-20" />

      <div className="two-col">
        <div className="card">
          <div className="card__head">
            <div className="card__title">Upcoming ex-dates</div>
            <div className="card__sub">Next 90 days</div>
          </div>
          <div className="tbl-wrap">
            <table className="tbl">
              <thead><tr>
                <th>Ticker</th><th>Ex-date</th><th className="num">Per share</th><th className="num">Total</th><th>Freq</th>
              </tr></thead>
              <tbody>
                {DIVIDENDS.sort((a, b) => a.ex_date.localeCompare(b.ex_date)).slice(0, 9).map((d, i) => (
                  <tr key={i}>
                    <td><div className="sym"><div className="sym__logo" style={{ background: d.color + '22', color: d.color, borderColor: d.color + '40' }}>{d.ticker.slice(0, 2)}</div><div className="sym__ticker">{d.ticker}</div></div></td>
                    <td>{d.ex_date}</td>
                    <td className="num">${d.per_share.toFixed(3)}</td>
                    <td className="num pos">+${fmt.money(d.total)}</td>
                    <td style={{ color: 'var(--ink-3)', fontSize: 11 }}>{d.frequency}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="card">
          <div className="card__head">
            <div className="card__title">Top dividend contributors</div>
            <div className="card__sub">Annualized payment · share of income</div>
          </div>
          <div style={{ padding: '18px 22px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {contributors.map(c => {
              const pct = (c.annual / contribTotal) * 100;
              return (
                <div key={c.ticker} style={{ display: 'grid', gridTemplateColumns: '80px 1fr 100px', alignItems: 'center', gap: 12, fontSize: 12.5 }}>
                  <div className="mono" style={{ fontWeight: 600, color: 'var(--ink)' }}>{c.ticker}</div>
                  <div style={{ position: 'relative', height: 22, background: 'var(--bg-3)', borderRadius: 4, overflow: 'hidden' }}>
                    <div style={{ position: 'absolute', inset: 0, width: `${pct}%`, background: c.color, opacity: 0.85 }} />
                    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', paddingLeft: 8, fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--bg)', fontWeight: 600 }}>
                      {c.yield.toFixed(2)}% yield
                    </div>
                  </div>
                  <div className="mono pos" style={{ textAlign: 'right', fontWeight: 500 }}>+${fmt.money(c.annual, 0)}/yr</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}

// =============================================================
// MARKETS / WATCHLIST / NEWS
// =============================================================
function MarketsTab() {
  const INDICES = [
    { name: 'S&P 500',  val: '5,318.24',  chg: +0.42, spark: genWalk(30, 5200, 0.01, 0.001, 1).map(v => v * 5318 / 5350) },
    { name: 'NASDAQ',   val: '16,742.10', chg: +0.81, spark: genWalk(30, 16400, 0.012, 0.001, 2).map(v => v * 16742 / 16800) },
    { name: 'DOW 30',   val: '39,410.77', chg: -0.12, spark: genWalk(30, 39500, 0.008, 0, 3).map(v => v * 39410 / 39520) },
    { name: 'DAX',      val: '18,212.44', chg: +0.68, spark: genWalk(30, 18000, 0.011, 0.0005, 4).map(v => v * 18212 / 18240) },
    { name: 'FTSE 100', val: '8,104.32',  chg: -0.24, spark: genWalk(30, 8080, 0.009, 0, 5).map(v => v * 8104 / 8100) },
    { name: 'Nikkei',   val: '38,204.12', chg: +1.12, spark: genWalk(30, 37800, 0.012, 0.0008, 6).map(v => v * 38204 / 38300) },
  ];

  return (
    <>
      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Global markets</div>
            <div className="card__sub">Major indices · 30-day trend</div>
          </div>
          <div className="pill pill--open"><span className="pill__dot" />Live</div>
        </div>
        <div style={{ padding: 20, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {INDICES.map(idx => (
            <div key={idx.name} style={{ padding: 16, border: '1px solid var(--line-soft)', borderRadius: 10, background: 'var(--bg)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <div>
                  <div style={{ fontSize: 11, color: 'var(--ink-4)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{idx.name}</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em', color: 'var(--ink)', marginTop: 4 }}>{idx.val}</div>
                </div>
                <div className={`mono ${idx.chg >= 0 ? 'pos' : 'neg'}`} style={{ fontWeight: 600, fontSize: 13 }}>
                  {idx.chg >= 0 ? '+' : ''}{idx.chg.toFixed(2)}%
                </div>
              </div>
              <div style={{ marginTop: 10 }}>
                <Sparkline data={idx.spark} width={250} height={36} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="spacer-20" />

      <div className="two-col">
        <div className="card">
          <div className="card__head">
            <div>
              <div className="card__title">Watchlist</div>
              <div className="card__sub">{WATCHLIST.length} symbols · not yet in portfolio</div>
            </div>
            <button className="btn btn--ghost" style={{ padding: '6px 10px', fontSize: 11 }}>{Icons.plus}<span>Add</span></button>
          </div>
          <div className="tbl-wrap">
            <table className="tbl">
              <thead><tr>
                <th>Symbol</th><th>Trend</th><th className="num">Last</th><th className="num">Day</th><th className="num">YTD</th>
              </tr></thead>
              <tbody>
                {WATCHLIST.map(w => (
                  <tr key={w.ticker}>
                    <td>
                      <div className="sym">
                        <div className="sym__logo" style={{ background: 'var(--bg-3)' }}>{w.ticker.slice(0, 2)}</div>
                        <div>
                          <div className="sym__ticker">{w.ticker}</div>
                          <div className="sym__name">{w.name}</div>
                        </div>
                      </div>
                    </td>
                    <td><Sparkline data={w.spark} width={60} height={20} /></td>
                    <td className="num" style={{ color: 'var(--ink)' }}>${fmt.money(w.px)}</td>
                    <td className={`num ${w.chg >= 0 ? 'pos' : 'neg'}`}>{w.chg >= 0 ? '+' : ''}{w.chg.toFixed(2)}%</td>
                    <td className={`num ${w.ytd >= 0 ? 'pos' : 'neg'}`}>{w.ytd >= 0 ? '+' : ''}{w.ytd.toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div className="card__head">
            <div>
              <div className="card__title">News feed</div>
              <div className="card__sub">Filtered for your holdings</div>
            </div>
            <div className="chip-group">
              <button className="active">All</button>
              <button>Macro</button>
              <button>Earnings</button>
            </div>
          </div>
          <div style={{ padding: '8px 0' }}>
            {NEWS.map((n, i) => (
              <div key={i} style={{ padding: '12px 22px', borderBottom: i < NEWS.length - 1 ? '1px solid var(--line-soft)' : 'none', display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <div style={{ width: 3, alignSelf: 'stretch', borderRadius: 2, background: n.impact === 'pos' ? 'var(--pos)' : 'var(--neg)', marginTop: 2 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 10.5, color: 'var(--ink-4)', fontFamily: 'var(--font-mono)', letterSpacing: '0.04em' }}>
                    <span style={{ color: 'var(--ink-3)', fontWeight: 600 }}>{n.src}</span>
                    <span>·</span><span>{n.tag}</span><span>·</span><span>{n.t} ago</span>
                  </div>
                  <div style={{ fontSize: 13, color: 'var(--ink)', marginTop: 5, lineHeight: 1.4, textWrap: 'pretty' }}>{n.headline}</div>
                  <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                    {n.tickers.map(t => (
                      <span key={t} className="mono" style={{ fontSize: 10, padding: '2px 6px', borderRadius: 4, background: 'var(--bg-2)', color: 'var(--ink-2)' }}>{t}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

// =============================================================
// CASHFLOWS / TRADES / FEES / TAXES
// =============================================================
function CashflowsTab() {
  const totalFees    = TRADES.reduce((s, t) => s + t.fee, 0);
  const totalInflow  = TRADES.filter(t => t.side === 'BUY').reduce((s, t) => s + t.qty * t.px, 0);
  const totalOutflow = TRADES.filter(t => t.side === 'SELL').reduce((s, t) => s + t.qty * t.px, 0);
  const realizedTax  = 1240.55; // mock

  return (
    <>
      <div className="three-col">
        <div className="metric">
          <div className="metric__label">Net deposits YTD</div>
          <div className="metric__val"><span className="cur">$</span>{fmt.money(totalInflow - totalOutflow, 0)}</div>
          <div className="metric__sub"><span style={{ color: 'var(--ink-4)' }}>{TRADES.length} trades</span></div>
        </div>
        <div className="metric">
          <div className="metric__label">Fees paid</div>
          <div className="metric__val"><span className="cur">$</span>{fmt.money(totalFees, 2)}</div>
          <div className="metric__sub"><span style={{ color: 'var(--ink-4)' }}>{(totalFees / totalInflow * 10000).toFixed(1)} bps avg</span></div>
        </div>
        <div className="metric">
          <div className="metric__label">Realized tax estimate</div>
          <div className="metric__val"><span className="cur">$</span>{fmt.money(realizedTax, 0)}</div>
          <div className="metric__sub"><span style={{ color: 'var(--ink-4)' }}>CH long-term · 0% · short ≈ 26%</span></div>
        </div>
      </div>

      <div className="spacer-20" />

      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Trade history</div>
            <div className="card__sub">All executed orders · synced from broker</div>
          </div>
          <div className="chip-group">
            <button className="active">All</button>
            <button>Buys</button>
            <button>Sells</button>
          </div>
        </div>
        <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr>
              <th>Date</th><th>Ticker</th><th>Side</th><th className="num">Qty</th><th className="num">Price</th><th className="num">Value</th><th className="num">Fee</th>
            </tr></thead>
            <tbody>
              {TRADES.map((t, i) => (
                <tr key={i}>
                  <td>{t.date}</td>
                  <td className="mono" style={{ color: 'var(--ink)', fontWeight: 600 }}>{t.ticker}</td>
                  <td>
                    <span style={{
                      padding: '2px 8px', borderRadius: 4, fontSize: 10.5, fontWeight: 600,
                      background: t.side === 'BUY' ? 'var(--pos-soft)' : 'var(--neg-soft)',
                      color: t.side === 'BUY' ? 'var(--pos)' : 'var(--neg)',
                      border: `1px solid ${t.side === 'BUY' ? 'var(--pos-line)' : 'var(--neg-line)'}`,
                    }}>{t.side}</span>
                  </td>
                  <td className="num">{t.qty}</td>
                  <td className="num">${fmt.money(t.px)}</td>
                  <td className="num" style={{ color: 'var(--ink)' }}>${fmt.money(t.qty * t.px, 2)}</td>
                  <td className="num" style={{ color: 'var(--ink-4)' }}>${t.fee.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

// =============================================================
// HEDGING — Black-Scholes put options
// =============================================================
function normCdf(x) {
  // Abramowitz-Stegun approximation
  const a1 =  0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const sign = x < 0 ? -1 : 1;
  const xx = Math.abs(x) / Math.SQRT2;
  const t = 1 / (1 + p * xx);
  const y = 1 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-xx * xx);
  return 0.5 * (1 + sign * y);
}
function normPdf(x) { return Math.exp(-x * x / 2) / Math.sqrt(2 * Math.PI); }

function blackScholes(S, K, T, r, sigma, type = 'put') {
  const d1 = (Math.log(S / K) + (r + sigma * sigma / 2) * T) / (sigma * Math.sqrt(T));
  const d2 = d1 - sigma * Math.sqrt(T);
  let price, delta, gamma, theta, vega;
  gamma = normPdf(d1) / (S * sigma * Math.sqrt(T));
  vega  = S * normPdf(d1) * Math.sqrt(T) / 100; // per 1% vol
  if (type === 'call') {
    price = S * normCdf(d1) - K * Math.exp(-r * T) * normCdf(d2);
    delta = normCdf(d1);
    theta = (-S * normPdf(d1) * sigma / (2 * Math.sqrt(T)) - r * K * Math.exp(-r * T) * normCdf(d2)) / 365;
  } else {
    price = K * Math.exp(-r * T) * normCdf(-d2) - S * normCdf(-d1);
    delta = normCdf(d1) - 1;
    theta = (-S * normPdf(d1) * sigma / (2 * Math.sqrt(T)) + r * K * Math.exp(-r * T) * normCdf(-d2)) / 365;
  }
  return { price, delta, gamma, theta, vega };
}

function HedgingTab() {
  const [strategy, setStrategy] = usX('put');
  const [ticker,   setTicker]   = usX('SPY');
  const [dte,      setDte]      = usX(60);
  const [moneyness,setMoneyness]= usX(95); // % of spot for strike
  const [sigma,    setSigma]    = usX(18); // annual vol %

  const S = 528.40; // SPY proxy
  const K = S * moneyness / 100;
  const T = dte / 365;
  const r = 0.042;
  const vol = sigma / 100;

  const bs = blackScholes(S, K, T, r, vol, strategy === 'put' ? 'put' : 'call');
  const contracts = Math.ceil(TOTALS.total_value / (S * 100) * 0.8); // 80% hedged
  const cost = bs.price * 100 * contracts;
  const costBps = (cost / TOTALS.total_value) * 10000;

  // payoff curve at expiry
  const payoffCurve = umX(() => {
    const pts = [];
    for (let i = 0; i <= 40; i++) {
      const spot = S * (0.7 + i / 40 * 0.6);
      const portfolioMove = (spot / S - 1) * TOTALS.total_value;
      const putPayoff = Math.max(K - spot, 0) * 100 * contracts - cost;
      const hedged = portfolioMove + (strategy === 'put' ? putPayoff : -cost);
      pts.push({ spot, unhedged: portfolioMove, hedged });
    }
    return pts;
  }, [S, K, contracts, cost, strategy]);

  const STRATS = [
    { id: 'put',         label: 'Protective puts', desc: 'Buy OTM puts to cap downside' },
    { id: 'collar',      label: 'Zero-cost collar', desc: 'Buy put · sell call · net ≈ 0 premium' },
    { id: 'reduce-beta', label: 'Reduce beta',     desc: 'Rotate into low-beta / defensive names' },
    { id: 'cash',        label: 'Raise cash',      desc: 'Trim winners · hold 10–20% in T-bills' },
  ];

  return (
    <>
      <div className="card" style={{ padding: 0 }}>
        <div className="card__head">
          <div>
            <div className="card__title">Hedging studio</div>
            <div className="card__sub">Model downside protection with Black–Scholes · educational, not advice</div>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0 }}>
          <div style={{ padding: 22, borderRight: '1px solid var(--line-soft)' }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}>Strategy</div>
            <div style={{ display: 'grid', gap: 8 }}>
              {STRATS.map(s => (
                <div key={s.id}
                     className={`scenario ${strategy === s.id ? 'scenario--selected' : ''}`}
                     onClick={() => setStrategy(s.id)}
                     style={{ cursor: 'pointer' }}>
                  <div>
                    <div className="scenario__name">{s.label}</div>
                    <div className="scenario__desc">{s.desc}</div>
                  </div>
                  <div style={{ fontSize: 18, color: 'var(--ink-4)' }}>{strategy === s.id ? '●' : '○'}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ padding: 22 }}>
            <div className="eyebrow" style={{ marginBottom: 14 }}>Parameters</div>
            <div style={{ display: 'grid', gap: 16 }}>
              <SliderRow label="Underlying" value={ticker} onChange={setTicker} readOnly />
              <SliderRow label={`Days to expiry`} value={dte} onChange={setDte} min={7} max={365} unit="d" />
              <SliderRow label={`Strike (% of spot)`} value={moneyness} onChange={setMoneyness} min={70} max={110} unit="%" />
              <SliderRow label={`Implied vol (annual)`} value={sigma} onChange={setSigma} min={8} max={60} unit="%" />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 22, paddingTop: 22, borderTop: '1px solid var(--line-soft)' }}>
              <Kpi label="Contracts" value={contracts} mono />
              <Kpi label="Total premium" value={`$${fmt.money(cost, 0)}`} mono />
              <Kpi label="Cost of hedge" value={`${costBps.toFixed(0)} bps`} mono accent />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginTop: 14 }}>
              <Kpi label="Δ Delta"  value={bs.delta.toFixed(3)} mono />
              <Kpi label="Γ Gamma"  value={bs.gamma.toFixed(4)} mono />
              <Kpi label="Θ Theta"  value={bs.theta.toFixed(2)} mono />
              <Kpi label="ν Vega"   value={bs.vega.toFixed(2)}  mono />
            </div>
          </div>
        </div>
      </div>

      <div className="spacer-20" />

      <div className="card">
        <div className="card__head">
          <div>
            <div className="card__title">Payoff at expiry</div>
            <div className="card__sub">Portfolio P&amp;L under each SPY scenario · hedged vs unhedged</div>
          </div>
        </div>
        <div style={{ padding: 22 }}>
          <PayoffChart data={payoffCurve} spot={S} strike={K} height={280} />
        </div>
      </div>

      <div className="spacer-20" />

      <div className="two-col">
        <div className="card card--pad">
          <div className="eyebrow">Risk reduction summary</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, marginTop: 10, color: 'var(--ink)', letterSpacing: '-0.01em' }}>
            If SPY falls −15%, this hedge saves you ${fmt.money(Math.max(0, (K - S * 0.85)) * 100 * contracts - cost, 0)}
          </div>
          <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
            <Row k="Portfolio value" v={`$${fmt.money(TOTALS.total_value, 0)}`} />
            <Row k="Coverage (beta-weighted)" v="≈ 80% of equity exposure" />
            <Row k="Breakeven move" v={`${((K - bs.price) / S * 100 - 100).toFixed(2)}%`} />
            <Row k="Max payoff" v={`$${fmt.money(K * 100 * contracts - cost, 0)}`} />
          </div>
        </div>
        <div className="card card--pad">
          <div className="eyebrow">Other ways to lower risk</div>
          <div style={{ display: 'grid', gap: 10, marginTop: 12 }}>
            {[
              { k: 'Add defensive ETFs', v: 'Utilities · staples · healthcare (XLU, XLP, XLV)' },
              { k: 'Duration barbell',   v: 'Short T-bills + long 10Y treasuries' },
              { k: 'Gold / BTC sleeve',  v: '5–10% allocation to uncorrelated stores of value' },
              { k: 'Low-beta rotation',  v: 'Target portfolio β ≤ 0.75 via tilts' },
              { k: 'Trailing stops',     v: 'Preserve gains on concentrated positions' },
              { k: 'Covered calls',      v: 'Generate yield on existing holdings' },
            ].map((it, i) => (
              <div key={i} style={{ padding: 12, border: '1px solid var(--line-soft)', borderRadius: 8, display: 'flex', justifyContent: 'space-between', gap: 12, fontSize: 12.5 }}>
                <span style={{ color: 'var(--ink)', fontWeight: 500 }}>{it.k}</span>
                <span style={{ color: 'var(--ink-3)', textAlign: 'right' }}>{it.v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

function SliderRow({ label, value, onChange, min, max, unit = '', readOnly }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
        <span style={{ fontSize: 11, color: 'var(--ink-3)', fontWeight: 500 }}>{label}</span>
        <span className="mono" style={{ fontSize: 13, color: 'var(--ink)', fontWeight: 600 }}>{value}{unit}</span>
      </div>
      {!readOnly && (
        <input type="range" min={min} max={max} value={value}
               onChange={e => onChange(+e.target.value)}
               style={{ width: '100%', accentColor: 'var(--pos)' }} />
      )}
    </div>
  );
}

function Kpi({ label, value, mono, accent }) {
  return (
    <div style={{ padding: '10px 12px', background: 'var(--bg)', border: '1px solid var(--line-soft)', borderRadius: 8 }}>
      <div style={{ fontSize: 10, color: 'var(--ink-4)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{label}</div>
      <div className={mono ? 'mono' : ''} style={{ fontSize: 15, marginTop: 3, color: accent ? 'var(--pos)' : 'var(--ink)', fontWeight: 600 }}>{value}</div>
    </div>
  );
}

function Row({ k, v }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--line-soft)', fontSize: 12.5 }}>
      <span style={{ color: 'var(--ink-3)' }}>{k}</span>
      <span className="mono" style={{ color: 'var(--ink)' }}>{v}</span>
    </div>
  );
}

function PayoffChart({ data, spot, strike, height = 260 }) {
  const [w, setW] = usX(640);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(es => setW(es[0].contentRect.width));
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);

  const all = data.flatMap(d => [d.unhedged, d.hedged]);
  const min = Math.min(...all), max = Math.max(...all);
  const range = max - min;
  const padL = 60, padR = 16, padT = 16, padB = 30;
  const innerW = w - padL - padR, innerH = height - padT - padB;
  const spots = data.map(d => d.spot);
  const sMin = Math.min(...spots), sMax = Math.max(...spots);
  const toX = s => padL + ((s - sMin) / (sMax - sMin)) * innerW;
  const toY = v => padT + innerH - ((v - min) / range) * innerH;

  const uLine = data.map((d, i) => (i ? 'L' : 'M') + toX(d.spot).toFixed(1) + ',' + toY(d.unhedged).toFixed(1)).join(' ');
  const hLine = data.map((d, i) => (i ? 'L' : 'M') + toX(d.spot).toFixed(1) + ',' + toY(d.hedged).toFixed(1)).join(' ');
  const zeroY = toY(0);

  return (
    <div ref={ref} style={{ width: '100%', position: 'relative' }}>
      <svg width={w} height={height}>
        {/* zero line */}
        <line x1={padL} x2={w - padR} y1={zeroY} y2={zeroY} stroke="var(--line)" />
        {/* spot marker */}
        <line x1={toX(spot)} x2={toX(spot)} y1={padT} y2={height - padB} stroke="var(--ink-4)" strokeDasharray="3 4" />
        <text x={toX(spot) + 4} y={padT + 10} fontSize="10" fill="var(--ink-4)" fontFamily="var(--font-mono)">spot ${spot}</text>
        {/* strike */}
        <line x1={toX(strike)} x2={toX(strike)} y1={padT} y2={height - padB} stroke="var(--pos)" strokeDasharray="3 4" />
        <text x={toX(strike) + 4} y={padT + 22} fontSize="10" fill="var(--pos)" fontFamily="var(--font-mono)">strike ${strike.toFixed(0)}</text>

        <path d={uLine} fill="none" stroke="var(--ink-3)" strokeWidth="1.6" strokeDasharray="4 4" />
        <path d={hLine} fill="none" stroke="var(--pos)" strokeWidth="2.2" />

        {/* axis ticks */}
        {[0, 0.25, 0.5, 0.75, 1].map((t, i) => {
          const v = min + range * t;
          const y = toY(v);
          return (
            <g key={i}>
              <text x={padL - 8} y={y + 3} fontSize="10" fill="var(--ink-4)" textAnchor="end" fontFamily="var(--font-mono)">
                {fmt.moneyCompact(v)}
              </text>
            </g>
          );
        })}
        <text x={padL} y={height - 8} fontSize="10" fill="var(--ink-4)" fontFamily="var(--font-mono)">${sMin.toFixed(0)}</text>
        <text x={w - padR} y={height - 8} fontSize="10" fill="var(--ink-4)" fontFamily="var(--font-mono)" textAnchor="end">${sMax.toFixed(0)}</text>
      </svg>

      <div style={{ position: 'absolute', top: 12, right: 20, display: 'flex', flexDirection: 'column', gap: 6, fontSize: 11, background: 'var(--bg-2)', padding: '8px 12px', borderRadius: 8, border: '1px solid var(--line)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 14, height: 2, background: 'var(--pos)' }} />
          <span style={{ color: 'var(--ink)' }}>Hedged</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 14, height: 2, background: 'var(--ink-3)', borderTop: '2px dashed var(--ink-3)' }} />
          <span style={{ color: 'var(--ink-3)' }}>Unhedged</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DividendsTab, MarketsTab, CashflowsTab, HedgingTab });
